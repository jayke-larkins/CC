import React from 'react';
import { AppProvider, useAppContext } from './components/AppContext';
import { BottomNavigation } from './components/shared/BottomNavigation';

// Screen Components
import { WelcomeScreen } from './components/screens/WelcomeScreen';
import { LoginScreen } from './components/screens/LoginScreen';
import { SignupScreen } from './components/screens/SignupScreen';
import { ParticipantHomeScreen } from './components/screens/ParticipantHomeScreen';
import { SupportWorkerHomeScreen } from './components/screens/SupportWorkerHomeScreen';
import { InboxScreen } from './components/screens/InboxScreen';
import { ChatScreen } from './components/screens/ChatScreen';
import { MenuScreen } from './components/screens/MenuScreen';
import { ScheduleScreen } from './components/screens/ScheduleScreen';
import { WorkerProfileScreen } from './components/screens/WorkerProfileScreen';
import { CredentialsScreen } from './components/screens/CredentialsScreen';
import { JobRequestsScreen } from './components/screens/JobRequestsScreen';
import { ParticipantProfileScreen } from './components/screens/ParticipantProfileScreen';
import { NotificationsScreen } from './components/screens/NotificationsScreen';
import { SavedWorkersScreen } from './components/screens/SavedWorkersScreen';
import { ReportingTemplatesScreen } from './components/screens/ReportingTemplatesScreen';

const AppContent: React.FC = () => {
  const { currentScreen, isAuthenticated, user } = useAppContext();

  const renderScreen = () => {
    // Unauthenticated screens
    if (!isAuthenticated) {
      switch (currentScreen) {
        case 'login':
          return <LoginScreen />;
        case 'signup':
          return <SignupScreen />;
        default:
          return <WelcomeScreen />;
      }
    }

    // Authenticated screens
    switch (currentScreen) {
      case 'participant-home':
        return <ParticipantHomeScreen />;
      case 'support-worker-home':
        return <SupportWorkerHomeScreen />;
      case 'inbox':
        return <InboxScreen />;
      case 'chat':
        return <ChatScreen />;
      case 'schedule':
        return <ScheduleScreen />;
      case 'worker-profile':
        return <WorkerProfileScreen />;
      case 'participant-profile':
        return <ParticipantProfileScreen />;
      case 'credentials':
        return <CredentialsScreen />;
      case 'job-requests':
        return <JobRequestsScreen />;
      case 'notifications':
        return <NotificationsScreen />;
      case 'saved-workers':
        return <SavedWorkersScreen />;
      case 'reporting-templates':
        return <ReportingTemplatesScreen />;
      case 'menu':
        return <MenuScreen />;
      // Default to role-appropriate home screen
      default:
        return user?.role === 'participant' ? <ParticipantHomeScreen /> : <SupportWorkerHomeScreen />;
    }
  };

  return (
    <div className="relative min-h-screen bg-background max-w-md mx-auto">
      {/* Main Content */}
      <main className="relative z-0">
        {renderScreen()}
      </main>

      {/* Bottom Navigation */}
      {isAuthenticated && (
        <div className="relative z-10">
          <BottomNavigation />
        </div>
      )}
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}