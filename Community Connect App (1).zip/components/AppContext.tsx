import React, { createContext, useContext, useState, ReactNode } from 'react';

export type UserRole = 'participant' | 'support-worker';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  suburb?: string;
  profileImage?: string;
}

export interface AppContextType {
  user: User | null;
  isAuthenticated: boolean;
  currentScreen: string;
  setCurrentScreen: (screen: string) => void;
  login: (user: User) => void;
  logout: () => void;
  signup: (userData: Omit<User, 'id'>) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};

interface AppProviderProps {
  children: ReactNode;
}

export const AppProvider: React.FC<AppProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [currentScreen, setCurrentScreen] = useState('welcome');

  const isAuthenticated = user !== null;

  const login = (userData: User) => {
    setUser(userData);
    setCurrentScreen(userData.role === 'participant' ? 'participant-home' : 'support-worker-home');
  };

  const logout = () => {
    setUser(null);
    setCurrentScreen('welcome');
  };

  const signup = (userData: Omit<User, 'id'>) => {
    const newUser: User = {
      ...userData,
      id: Math.random().toString(36).substr(2, 9),
    };
    setUser(newUser);
    setCurrentScreen(newUser.role === 'participant' ? 'participant-home' : 'support-worker-home');
  };

  return (
    <AppContext.Provider
      value={{
        user,
        isAuthenticated,
        currentScreen,
        setCurrentScreen,
        login,
        logout,
        signup,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};