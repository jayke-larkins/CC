export interface SupportWorker {
  id: string;
  name: string;
  suburb: string;
  yearsExperience: number;
  isNDISExperienced: boolean;
  isVerified: boolean;
  isOnline: boolean;
  tagline: string;
  profileImage: string;
  credentials: {
    workingWithChildren: boolean;
    policeCheck: boolean;
    ndisOrientation: boolean;
    firstAid: boolean;
    driverLicense: boolean;
  };
}

export interface JobPost {
  id: string;
  participantId: string;
  participantName: string;
  participantSuburb: string;
  title: string;
  description: string;
  date: string;
  time: string;
  supportType: string;
  location: string;
  interestedWorkers: string[];
}

export interface Message {
  id: string;
  senderId: string;
  receiverId: string;
  content: string;
  timestamp: Date;
  isRead: boolean;
}

export interface Conversation {
  id: string;
  participantId: string;
  workerId: string;
  participantName: string;
  workerName: string;
  lastMessage: string;
  lastMessageTime: Date;
  profileImage: string;
  isOnline: boolean;
}

export const mockSupportWorkers: SupportWorker[] = [
  {
    id: '1',
    name: 'Sarah Mitchell',
    suburb: 'Richmond',
    yearsExperience: 5,
    isNDISExperienced: true,
    isVerified: true,
    isOnline: true,
    tagline: 'Passionate about helping others achieve their goals',
    profileImage: 'https://images.unsplash.com/photo-1494790108755-2616b612b8c5?w=150&h=150&fit=crop&crop=face',
    credentials: {
      workingWithChildren: true,
      policeCheck: true,
      ndisOrientation: true,
      firstAid: true,
      driverLicense: true,
    },
  },
  {
    id: '2',
    name: 'Marcus Chen',
    suburb: 'Brunswick',
    yearsExperience: 3,
    isNDISExperienced: true,
    isVerified: true,
    isOnline: false,
    tagline: 'Experienced in mobility support and daily living assistance',
    profileImage: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face',
    credentials: {
      workingWithChildren: true,
      policeCheck: true,
      ndisOrientation: true,
      firstAid: false,
      driverLicense: true,
    },
  },
  {
    id: '3',
    name: 'Emma Thompson',
    suburb: 'Fitzroy',
    yearsExperience: 7,
    isNDISExperienced: true,
    isVerified: true,
    isOnline: true,
    tagline: 'Specialized in social and community participation',
    profileImage: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face',
    credentials: {
      workingWithChildren: true,
      policeCheck: true,
      ndisOrientation: true,
      firstAid: true,
      driverLicense: true,
    },
  },
  {
    id: '4',
    name: 'David Rodriguez',
    suburb: 'Carlton',
    yearsExperience: 2,
    isNDISExperienced: false,
    isVerified: false,
    isOnline: true,
    tagline: 'New to support work but eager to learn and help',
    profileImage: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face',
    credentials: {
      workingWithChildren: true,
      policeCheck: false,
      ndisOrientation: false,
      firstAid: true,
      driverLicense: true,
    },
  },
];

export const mockJobPosts: JobPost[] = [
  {
    id: '1',
    participantId: 'p1',
    participantName: 'Alex Johnson',
    participantSuburb: 'Richmond',
    title: 'Grocery Shopping Assistance',
    description: 'Need help with weekly grocery shopping at Coles Richmond. Looking for someone who can assist with mobility and carrying items.',
    date: '2025-01-25',
    time: '10:00 AM',
    supportType: 'Daily Living',
    location: 'Coles Richmond',
    interestedWorkers: ['1', '3'],
  },
  {
    id: '2',
    participantId: 'p2',
    participantName: 'Jordan Smith',
    participantSuburb: 'Brunswick',
    title: 'Gym Buddy Needed',
    description: 'Looking for a support worker to accompany me to the local gym for my weekly workout session. Need someone confident with exercise equipment.',
    date: '2025-01-26',
    time: '2:00 PM',
    supportType: 'Recreation',
    location: 'Anytime Fitness Brunswick',
    interestedWorkers: ['2'],
  },
  {
    id: '3',
    participantId: 'p3',
    participantName: 'Casey Williams',
    participantSuburb: 'Fitzroy',
    title: 'Doctor Appointment Support',
    description: 'Need someone to accompany me to my specialist appointment. Must have reliable transport and be comfortable in medical settings.',
    date: '2025-01-27',
    time: '11:30 AM',
    supportType: 'Transport',
    location: 'Royal Melbourne Hospital',
    interestedWorkers: [],
  },
];

export const mockConversations: Conversation[] = [
  {
    id: '1',
    participantId: 'p1',
    workerId: '1',
    participantName: 'Alex Johnson',
    workerName: 'Sarah Mitchell',
    lastMessage: 'Thanks for confirming! See you at 10 AM tomorrow.',
    lastMessageTime: new Date('2025-01-23T15:30:00'),
    profileImage: 'https://images.unsplash.com/photo-1494790108755-2616b612b8c5?w=150&h=150&fit=crop&crop=face',
    isOnline: true,
  },
  {
    id: '2',
    participantId: 'p2',
    workerId: '2',
    participantName: 'Jordan Smith',
    workerName: 'Marcus Chen',
    lastMessage: 'I have experience with gym equipment, happy to help!',
    lastMessageTime: new Date('2025-01-23T12:15:00'),
    profileImage: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face',
    isOnline: false,
  },
  {
    id: '3',
    participantId: 'p1',
    workerId: '3',
    participantName: 'Alex Johnson',
    workerName: 'Emma Thompson',
    lastMessage: 'Hi! I saw your job post and I&apos;m interested.',
    lastMessageTime: new Date('2025-01-22T18:45:00'),
    profileImage: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face',
    isOnline: true,
  },
];