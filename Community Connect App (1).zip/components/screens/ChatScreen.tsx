import React, { useState } from 'react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { useAppContext } from '../AppContext';
import { ArrowLeft, Send, MoreVertical, Phone, Video, Info } from 'lucide-react';

interface Message {
  id: string;
  text: string;
  timestamp: Date;
  isFromUser: boolean;
  status?: 'sent' | 'delivered' | 'read';
}

const mockMessages: Message[] = [
  {
    id: '1',
    text: 'Hi Sarah! I saw your profile and I\'m interested in your personal care services. Are you available this week?',
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
    isFromUser: true,
    status: 'read'
  },
  {
    id: '2',
    text: 'Hello! Thanks for reaching out. Yes, I have availability this week. What type of support are you looking for?',
    timestamp: new Date(Date.now() - 1.5 * 60 * 60 * 1000), // 1.5 hours ago
    isFromUser: false
  },
  {
    id: '3',
    text: 'I need help with grocery shopping and some light household tasks. Would Tuesday or Wednesday work for you?',
    timestamp: new Date(Date.now() - 1 * 60 * 60 * 1000), // 1 hour ago
    isFromUser: true,
    status: 'read'
  },
  {
    id: '4',
    text: 'Perfect! Tuesday works great for me. I usually do grocery shopping in the morning around 10am. Would that suit you?',
    timestamp: new Date(Date.now() - 45 * 60 * 1000), // 45 minutes ago
    isFromUser: false
  },
  {
    id: '5',
    text: 'That sounds perfect! Should we meet at your place or would you prefer to meet at the shops?',
    timestamp: new Date(Date.now() - 30 * 60 * 1000), // 30 minutes ago
    isFromUser: true,
    status: 'delivered'
  },
  {
    id: '6',
    text: 'I can come to your place first and we can go together. That way I can also help with the household tasks afterwards. My rate is $35/hour for these services.',
    timestamp: new Date(Date.now() - 15 * 60 * 1000), // 15 minutes ago
    isFromUser: false
  }
];

export const ChatScreen: React.FC = () => {
  const { user, setCurrentScreen } = useAppContext();
  const [newMessage, setNewMessage] = useState('');
  const [messages, setMessages] = useState<Message[]>(mockMessages);

  const otherPersonName = user?.role === 'participant' ? 'Sarah Mitchell' : 'Alex Johnson';
  const otherPersonRole = user?.role === 'participant' ? 'Support Worker' : 'Participant';

  const handleSendMessage = () => {
    if (newMessage.trim()) {
      const message: Message = {
        id: Date.now().toString(),
        text: newMessage.trim(),
        timestamp: new Date(),
        isFromUser: true,
        status: 'sent'
      };
      
      setMessages(prev => [...prev, message]);
      setNewMessage('');
    }
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-AU', { 
      hour: '2-digit', 
      minute: '2-digit',
      hour12: true 
    });
  };

  const formatDate = (date: Date) => {
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    
    if (date.toDateString() === today.toDateString()) {
      return 'Today';
    } else if (date.toDateString() === yesterday.toDateString()) {
      return 'Yesterday';
    } else {
      return date.toLocaleDateString('en-AU', { 
        weekday: 'long',
        month: 'short',
        day: 'numeric'
      });
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col pb-20">
      {/* Header */}
      <div className="bg-gradient-to-r from-sage to-teal px-6 py-4 pt-12">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setCurrentScreen('inbox')}
              className="text-white hover:bg-white/20 rounded-full p-2"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                <span className="text-white text-sm">{otherPersonName.split(' ').map(n => n[0]).join('')}</span>
              </div>
              <div>
                <h2 className="text-white">{otherPersonName}</h2>
                <p className="text-white/80 text-xs">{otherPersonRole} • Online</p>
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              className="text-white hover:bg-white/20 rounded-full p-2"
            >
              <Phone className="w-5 h-5" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="text-white hover:bg-white/20 rounded-full p-2"
            >
              <Video className="w-5 h-5" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="text-white hover:bg-white/20 rounded-full p-2"
            >
              <MoreVertical className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4">
        {messages.map((message, index) => {
          const prevMessage = messages[index - 1];
          const showDate = !prevMessage || 
            formatDate(message.timestamp) !== formatDate(prevMessage.timestamp);
          
          return (
            <div key={message.id}>
              {/* Date Header */}
              {showDate && (
                <div className="flex justify-center mb-4">
                  <span className="bg-muted px-3 py-1 rounded-full text-xs text-muted-foreground">
                    {formatDate(message.timestamp)}
                  </span>
                </div>
              )}
              
              {/* Message */}
              <div className={`flex ${message.isFromUser ? 'justify-end' : 'justify-start'}`}>
                <div className="max-w-[80%]">
                  <div
                    className={`px-4 py-3 rounded-2xl ${
                      message.isFromUser
                        ? 'bg-teal-dark text-white rounded-br-sm'
                        : 'bg-muted text-foreground rounded-bl-sm'
                    }`}
                  >
                    <p className="text-sm">{message.text}</p>
                  </div>
                  
                  {/* Timestamp and Status */}
                  <div className={`flex items-center mt-1 space-x-1 ${
                    message.isFromUser ? 'justify-end' : 'justify-start'
                  }`}>
                    <span className="text-xs text-muted-foreground">
                      {formatTime(message.timestamp)}
                    </span>
                    {message.isFromUser && message.status && (
                      <div className={`w-3 h-3 rounded-full ${
                        message.status === 'sent' ? 'bg-gray-400' :
                        message.status === 'delivered' ? 'bg-blue-400' :
                        'bg-green-400'
                      }`} />
                    )}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Message Input */}
      <div className="border-t border-border p-4 bg-white">
        <div className="flex items-center space-x-3">
          <div className="flex-1 relative">
            <Input
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              placeholder="Type a message..."
              className="pr-12 rounded-full border-0 bg-muted"
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
            />
          </div>
          <Button
            onClick={handleSendMessage}
            disabled={!newMessage.trim()}
            className="bg-teal-dark hover:bg-teal text-white rounded-full w-12 h-12 p-0"
          >
            <Send className="w-5 h-5" />
          </Button>
        </div>
      </div>
    </div>
  );
};