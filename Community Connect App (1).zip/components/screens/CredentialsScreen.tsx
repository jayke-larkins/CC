import React, { useState } from 'react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { useAppContext } from '../AppContext';
import { 
  ArrowLeft, 
  Upload, 
  CheckCircle2, 
  AlertCircle, 
  Calendar, 
  FileText,
  Shield,
  Plus,
  Eye
} from 'lucide-react';

interface Credential {
  id: string;
  name: string;
  description: string;
  required: boolean;
  completed: boolean;
  expiryDate?: string;
  uploadedDate?: string;
  category: 'essential' | 'safety' | 'specialized' | 'business';
}

const credentials: Credential[] = [
  {
    id: 'ndis-orientation',
    name: 'NDIS Worker Orientation Module',
    description: 'Required for all registered support workers',
    required: true,
    completed: true,
    uploadedDate: '2024-01-15',
    category: 'essential'
  },
  {
    id: 'wwcc',
    name: 'Working with Children Check (WWCC)',
    description: 'Essential for working with participants under 18',
    required: true,
    completed: true,
    expiryDate: '2026-03-15',
    uploadedDate: '2024-03-15',
    category: 'safety'
  },
  {
    id: 'police-check',
    name: 'National Police Check',
    description: 'Must be current and clear',
    required: true,
    completed: false,
    category: 'safety'
  },
  {
    id: 'first-aid',
    name: 'First Aid Certificate (HLTAID011)',
    description: 'Provide First Aid or equivalent',
    required: true,
    completed: true,
    expiryDate: '2025-08-20',
    uploadedDate: '2024-08-20',
    category: 'safety'
  },
  {
    id: 'cpr',
    name: 'CPR Certificate (HLTAID009)',
    description: 'Often bundled with First Aid',
    required: true,
    completed: true,
    expiryDate: '2025-08-20',
    uploadedDate: '2024-08-20',
    category: 'safety'
  },
  {
    id: 'drivers-license',
    name: 'Driver\'s License',
    description: 'For transport-based supports',
    required: true,
    completed: true,
    expiryDate: '2027-12-10',
    uploadedDate: '2024-01-10',
    category: 'essential'
  },
  {
    id: 'insurance',
    name: 'Proof of Insurance',
    description: 'Public liability + personal indemnity',
    required: true,
    completed: false,
    category: 'business'
  },
  {
    id: 'covid-vaccination',
    name: 'COVID-19 Vaccination Evidence',
    description: 'May be required by some participants',
    required: false,
    completed: true,
    uploadedDate: '2024-02-01',
    category: 'safety'
  },
  {
    id: 'manual-handling',
    name: 'Manual Handling Training',
    description: 'Especially for physical support roles',
    required: false,
    completed: false,
    category: 'specialized'
  },
  {
    id: 'mental-health-first-aid',
    name: 'Mental Health First Aid',
    description: 'Great for psychosocial support contexts',
    required: false,
    completed: true,
    uploadedDate: '2024-06-10',
    category: 'specialized'
  },
  {
    id: 'blue-card',
    name: 'Blue Card / Yellow Card (QLD)',
    description: 'Queensland-specific working with children check',
    required: false,
    completed: false,
    category: 'safety'
  },
  {
    id: 'abn',
    name: 'ABN (Australian Business Number)',
    description: 'If working as sole trader or independent contractor',
    required: true,
    completed: true,
    uploadedDate: '2024-01-05',
    category: 'business'
  },
];

export const CredentialsScreen: React.FC = () => {
  const { setCurrentScreen } = useAppContext();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const categories = [
    { id: 'all', label: 'All', count: credentials.length },
    { id: 'essential', label: 'Essential', count: credentials.filter(c => c.category === 'essential').length },
    { id: 'safety', label: 'Safety', count: credentials.filter(c => c.category === 'safety').length },
    { id: 'specialized', label: 'Specialized', count: credentials.filter(c => c.category === 'specialized').length },
    { id: 'business', label: 'Business', count: credentials.filter(c => c.category === 'business').length },
  ];

  const filteredCredentials = selectedCategory === 'all' 
    ? credentials 
    : credentials.filter(c => c.category === selectedCategory);

  const completedCount = credentials.filter(c => c.completed).length;
  const requiredCount = credentials.filter(c => c.required).length;
  const completedRequired = credentials.filter(c => c.required && c.completed).length;

  const completionPercentage = Math.round((completedCount / credentials.length) * 100);

  const isExpiringSoon = (expiryDate?: string) => {
    if (!expiryDate) return false;
    const expiry = new Date(expiryDate);
    const now = new Date();
    const threeMonthsFromNow = new Date();
    threeMonthsFromNow.setMonth(now.getMonth() + 3);
    return expiry <= threeMonthsFromNow;
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-AU', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    });
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="bg-gradient-to-r from-sage to-teal px-6 py-8 pt-12">
        <div className="flex items-center mb-6">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setCurrentScreen('worker-profile')}
            className="text-white hover:bg-white/20 rounded-full p-2 mr-3"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-white text-2xl">Credentials</h1>
            <p className="text-white/90 text-sm">Manage your professional documents</p>
          </div>
        </div>

        {/* Progress Overview */}
        <Card className="bg-white/95 backdrop-blur-sm border-0 shadow-xl">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h3 className="text-sm">Overall Progress</h3>
                <p className="text-xs text-muted-foreground">
                  Required: {completedRequired}/{requiredCount} • Total: {completedCount}/{credentials.length}
                </p>
              </div>
              <Badge variant="outline" className="text-teal-dark border-teal-dark">
                {completionPercentage}%
              </Badge>
            </div>
            <Progress value={completionPercentage} className="h-2" />
          </CardContent>
        </Card>
      </div>

      {/* Category Filter */}
      <div className="px-6 py-4 border-b border-border">
        <div className="flex gap-2 overflow-x-auto pb-2">
          {categories.map((category) => (
            <Button
              key={category.id}
              variant={selectedCategory === category.id ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedCategory(category.id)}
              className={`whitespace-nowrap ${
                selectedCategory === category.id 
                  ? 'bg-teal-dark text-white' 
                  : 'text-muted-foreground'
              }`}
            >
              {category.label} ({category.count})
            </Button>
          ))}
        </div>
      </div>

      {/* Credentials List */}
      <div className="px-6 py-6 space-y-3">
        {filteredCredentials.map((credential) => (
          <Card key={credential.id} className="border-0 shadow-sm">
            <CardContent className="p-4">
              <div className="flex items-start space-x-3">
                {/* Status Icon */}
                <div className="pt-1">
                  {credential.completed ? (
                    <CheckCircle2 className="w-5 h-5 text-green-500" />
                  ) : (
                    <AlertCircle className="w-5 h-5 text-orange-500" />
                  )}
                </div>

                {/* Content */}
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h4 className="text-sm">{credential.name}</h4>
                      <p className="text-xs text-muted-foreground mt-1">
                        {credential.description}
                      </p>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      {credential.required && (
                        <Badge variant="outline" className="text-xs border-red-500 text-red-500">
                          Required
                        </Badge>
                      )}
                    </div>
                  </div>

                  {/* Status Details */}
                  {credential.completed ? (
                    <div className="space-y-1">
                      {credential.uploadedDate && (
                        <div className="flex items-center text-xs text-muted-foreground">
                          <FileText className="w-3 h-3 mr-1" />
                          Uploaded: {formatDate(credential.uploadedDate)}
                        </div>
                      )}
                      {credential.expiryDate && (
                        <div className={`flex items-center text-xs ${
                          isExpiringSoon(credential.expiryDate) 
                            ? 'text-orange-600' 
                            : 'text-muted-foreground'
                        }`}>
                          <Calendar className="w-3 h-3 mr-1" />
                          Expires: {formatDate(credential.expiryDate)}
                          {isExpiringSoon(credential.expiryDate) && ' (Soon)'}
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="text-xs text-muted-foreground">
                      Document not uploaded
                    </div>
                  )}

                  {/* Actions */}
                  <div className="flex gap-2 mt-3">
                    {credential.completed ? (
                      <>
                        <Button size="sm" variant="outline" className="text-xs h-8">
                          <Eye className="w-3 h-3 mr-1" />
                          View
                        </Button>
                        <Button size="sm" variant="outline" className="text-xs h-8">
                          <Upload className="w-3 h-3 mr-1" />
                          Replace
                        </Button>
                      </>
                    ) : (
                      <Button size="sm" className="text-xs h-8 bg-teal-dark hover:bg-teal">
                        <Upload className="w-3 h-3 mr-1" />
                        Upload Document
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};