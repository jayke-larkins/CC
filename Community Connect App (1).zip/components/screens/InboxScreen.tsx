import React, { useState } from 'react';
import { Card, CardContent } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Checkbox } from '../ui/checkbox';
import { useAppContext } from '../AppContext';
import { mockConversations } from '../MockData';
import { MessageSquare, Search, Flag, Trash2, MoreVertical } from 'lucide-react';
import { Input } from '../ui/input';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '../ui/dropdown-menu';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '../ui/alert-dialog';

export const InboxScreen: React.FC = () => {
  const { user, setCurrentScreen } = useAppContext();
  const [isSelectMode, setIsSelectMode] = useState(false);
  const [selectedConversations, setSelectedConversations] = useState<string[]>([]);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [showReportDialog, setShowReportDialog] = useState(false);
  const [reportReason, setReportReason] = useState('');

  const handleOpenChat = (conversationId: string) => {
    if (!isSelectMode) {
      setCurrentScreen('chat');
      // In a real app, you'd pass the conversation data to the chat view
    }
  };

  const handleSelectConversation = (conversationId: string, checked: boolean) => {
    if (checked) {
      setSelectedConversations(prev => [...prev, conversationId]);
    } else {
      setSelectedConversations(prev => prev.filter(id => id !== conversationId));
    }
  };

  const handleSelectAll = () => {
    if (selectedConversations.length === mockConversations.length) {
      setSelectedConversations([]);
    } else {
      setSelectedConversations(mockConversations.map(c => c.id));
    }
  };

  const handleDelete = () => {
    // In real app, delete selected conversations
    setSelectedConversations([]);
    setIsSelectMode(false);
    setShowDeleteDialog(false);
  };

  const handleReport = () => {
    // In real app, report selected conversations
    setSelectedConversations([]);
    setIsSelectMode(false);
    setShowReportDialog(false);
    setReportReason('');
  };

  const formatTime = (date: Date) => {
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) {
      return 'Just now';
    } else if (diffInHours < 24) {
      return `${diffInHours}h ago`;
    } else {
      const diffInDays = Math.floor(diffInHours / 24);
      return `${diffInDays}d ago`;
    }
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="bg-gradient-to-r from-sage to-teal px-6 py-8 pt-12">
        <div className="flex items-center justify-between mb-4">
          <div className="flex-1">
            <h1 className="text-white text-2xl">Messages</h1>
            <p className="text-white/90 text-sm">Your conversations</p>
          </div>
          
          {/* Header Actions */}
          <div className="flex items-center space-x-2">
            {!isSelectMode ? (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsSelectMode(true)}
                className="text-white hover:bg-white/20 rounded-full px-3"
              >
                Select
              </Button>
            ) : (
              <div className="flex items-center space-x-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleSelectAll}
                  className="text-white hover:bg-white/20 rounded-full px-3 text-xs"
                >
                  {selectedConversations.length === mockConversations.length ? 'Deselect All' : 'Select All'}
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    setIsSelectMode(false);
                    setSelectedConversations([]);
                  }}
                  className="text-white hover:bg-white/20 rounded-full px-3 text-xs"
                >
                  Cancel
                </Button>
              </div>
            )}
          </div>
        </div>
        
        {/* Search */}
        {!isSelectMode && (
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search conversations..."
              className="pl-10 bg-white/90 border-0 rounded-xl"
            />
          </div>
        )}
      </div>

      {/* Selection Actions Bar */}
      {isSelectMode && selectedConversations.length > 0 && (
        <div className="bg-white border-b border-border px-6 py-3">
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">
              {selectedConversations.length} selected
            </span>
            <div className="flex items-center space-x-3">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowReportDialog(true)}
                className="text-orange-600 hover:bg-orange-50"
              >
                <Flag className="w-4 h-4 mr-1" />
                Report
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowDeleteDialog(true)}
                className="text-red-600 hover:bg-red-50"
              >
                <Trash2 className="w-4 h-4 mr-1" />
                Delete
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Conversations */}
      <div className="px-6 py-6">
        {mockConversations.length > 0 ? (
          <div className="space-y-3">
            {mockConversations.map((conversation) => (
              <Card 
                key={conversation.id} 
                className={`border-0 shadow-sm hover:shadow-md transition-shadow ${
                  !isSelectMode ? 'cursor-pointer' : ''
                } ${
                  selectedConversations.includes(conversation.id) ? 'ring-2 ring-teal-dark' : ''
                }`}
                onClick={isSelectMode ? undefined : () => handleOpenChat(conversation.id)}
              >
                <CardContent className="p-4">
                  <div className="flex items-center space-x-4">
                    {/* Selection Checkbox */}
                    {isSelectMode && (
                      <Checkbox
                        checked={selectedConversations.includes(conversation.id)}
                        onCheckedChange={(checked) => 
                          handleSelectConversation(conversation.id, checked as boolean)
                        }
                        className="data-[state=checked]:bg-teal-dark data-[state=checked]:border-teal-dark"
                      />
                    )}

                    {/* Profile Image */}
                    <div className="relative">
                      <img
                        src={conversation.profileImage}
                        alt={user?.role === 'participant' ? conversation.workerName : conversation.participantName}
                        className="w-12 h-12 rounded-full object-cover"
                      />
                      {conversation.isOnline && (
                        <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>
                      )}
                    </div>

                    {/* Message Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <h3 className="truncate">
                          {user?.role === 'participant' ? conversation.workerName : conversation.participantName}
                        </h3>
                        <div className="flex items-center space-x-2">
                          <span className="text-xs text-muted-foreground">
                            {formatTime(conversation.lastMessageTime)}
                          </span>
                          {!isSelectMode && (
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="p-1 h-auto hover:bg-muted"
                                  onClick={(e) => e.stopPropagation()}
                                >
                                  <MoreVertical className="w-4 h-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem 
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setSelectedConversations([conversation.id]);
                                    setShowReportDialog(true);
                                  }}
                                  className="text-orange-600"
                                >
                                  <Flag className="w-4 h-4 mr-2" />
                                  Report
                                </DropdownMenuItem>
                                <DropdownMenuItem 
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setSelectedConversations([conversation.id]);
                                    setShowDeleteDialog(true);
                                  }}
                                  className="text-red-600"
                                >
                                  <Trash2 className="w-4 h-4 mr-2" />
                                  Delete
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          )}
                        </div>
                      </div>
                      
                      <p className="text-sm text-muted-foreground truncate">
                        {conversation.lastMessage}
                      </p>
                    </div>

                    {/* Online Badge */}
                    {conversation.isOnline && !isSelectMode && (
                      <Badge variant="outline" className="text-green-600 border-green-600 text-xs">
                        Online
                      </Badge>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          /* Empty State */
          <div className="flex-1 flex items-center justify-center py-20">
            <div className="text-center">
              <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                <MessageSquare className="w-10 h-10 text-muted-foreground" />
              </div>
              <h3 className="text-lg mb-2">No messages yet</h3>
              <p className="text-muted-foreground text-sm">
                Start connecting with {user?.role === 'participant' ? 'support workers' : 'participants'} to begin conversations.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent className="mx-6">
          <AlertDialogHeader>
            <AlertDialogTitle>Are You Sure You Want To Remove This Chat?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. The conversation will be permanently deleted from your inbox.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-gray-500 text-white hover:bg-gray-600">
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDelete}
              className="bg-green-500 text-white hover:bg-green-600"
            >
              Confirm
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Report Dialog */}
      <AlertDialog open={showReportDialog} onOpenChange={setShowReportDialog}>
        <AlertDialogContent className="mx-6">
          <AlertDialogHeader>
            <AlertDialogTitle>Report This User</AlertDialogTitle>
            <AlertDialogDescription>
              Please select a reason and provide additional details.
            </AlertDialogDescription>
          </AlertDialogHeader>
          
          <div className="space-y-4">
            <div className="space-y-2">
              {['Abusive behaviour', 'Inappropriate content', 'Spam', 'Other'].map((reason) => (
                <label key={reason} className="flex items-center space-x-2">
                  <input
                    type="radio"
                    name="reportReason"
                    value={reason}
                    checked={reportReason === reason}
                    onChange={(e) => setReportReason(e.target.value)}
                    className="w-4 h-4 text-teal-dark"
                  />
                  <span className="text-sm">{reason}</span>
                </label>
              ))}
            </div>
            
            <div>
              <label className="text-sm text-muted-foreground">Further details</label>
              <textarea
                className="w-full mt-1 p-2 border border-border rounded-md text-sm"
                rows={3}
                placeholder="Please provide additional details about the issue..."
              />
            </div>
          </div>

          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleReport}
              disabled={!reportReason}
              className="bg-teal-dark text-white hover:bg-teal"
            >
              Submit
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};