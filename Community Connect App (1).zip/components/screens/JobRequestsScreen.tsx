import React, { useState } from 'react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { useAppContext } from '../AppContext';
import { Calendar, MapPin, Clock, DollarSign, Plus, ArrowLeft } from 'lucide-react';

export const JobRequestsScreen: React.FC = () => {
  const { user, setCurrentScreen } = useAppContext();
  const [isCreatingRequest, setIsCreatingRequest] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    date: '',
    time: '',
    duration: '',
    supportType: '',
    location: '',
    budget: '',
    requirements: '',
  });

  const supportTypes = [
    'Personal Care',
    'Daily Living',
    'Transport',
    'Recreation',
    'Community Participation',
    'Household Tasks',
    'Shopping',
    'Medical Appointments',
    'Social Support',
    'Other'
  ];

  const handleSubmit = () => {
    // In real app, would submit to backend
    alert('Support request submitted successfully!');
    setFormData({
      title: '',
      description: '',
      date: '',
      time: '',
      duration: '',
      supportType: '',
      location: '',
      budget: '',
      requirements: '',
    });
    setIsCreatingRequest(false);
  };

  const isFormValid = formData.title && formData.description && formData.date && 
    formData.time && formData.supportType && formData.location;

  if (isCreatingRequest) {
    return (
      <div className="min-h-screen bg-background pb-20">
        {/* Header */}
        <div className="bg-gradient-to-r from-sage to-teal px-6 py-8 pt-12">
          <div className="flex items-center mb-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsCreatingRequest(false)}
              className="text-white hover:bg-white/20 rounded-full p-2 mr-3"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-white text-2xl">Create Support Request</h1>
              <p className="text-white/90 text-sm">Tell us what support you need</p>
            </div>
          </div>
        </div>

        {/* Form */}
        <div className="px-6 py-6 space-y-6">
          {/* Title */}
          <div className="space-y-2">
            <Label htmlFor="title">Request Title *</Label>
            <Input
              id="title"
              placeholder="e.g. Grocery Shopping Assistance"
              value={formData.title}
              onChange={(e) => setFormData({...formData, title: e.target.value})}
              className="bg-input-background border-0 rounded-xl"
            />
          </div>

          {/* Description */}
          <div className="space-y-2">
            <Label htmlFor="description">Description *</Label>
            <Textarea
              id="description"
              placeholder="Describe what support you need and any specific requirements..."
              value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})}
              className="bg-input-background border-0 rounded-xl min-h-24"
              rows={4}
            />
          </div>

          {/* Date and Time */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="date">Date *</Label>
              <div className="relative">
                <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  id="date"
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({...formData, date: e.target.value})}
                  className="pl-10 bg-input-background border-0 rounded-xl"
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="time">Time *</Label>
              <div className="relative">
                <Clock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  id="time"
                  type="time"
                  value={formData.time}
                  onChange={(e) => setFormData({...formData, time: e.target.value})}
                  className="pl-10 bg-input-background border-0 rounded-xl"
                />
              </div>
            </div>
          </div>

          {/* Duration and Support Type */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="duration">Duration</Label>
              <Input
                id="duration"
                placeholder="e.g. 2 hours"
                value={formData.duration}
                onChange={(e) => setFormData({...formData, duration: e.target.value})}
                className="bg-input-background border-0 rounded-xl"
              />
            </div>
            
            <div className="space-y-2">
              <Label>Support Type *</Label>
              <Select value={formData.supportType} onValueChange={(value) => setFormData({...formData, supportType: value})}>
                <SelectTrigger className="bg-input-background border-0 rounded-xl">
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  {supportTypes.map(type => (
                    <SelectItem key={type} value={type}>{type}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Location */}
          <div className="space-y-2">
            <Label htmlFor="location">Location *</Label>
            <div className="relative">
              <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                id="location"
                placeholder="e.g. Coles Richmond, 123 Swan Street"
                value={formData.location}
                onChange={(e) => setFormData({...formData, location: e.target.value})}
                className="pl-10 bg-input-background border-0 rounded-xl"
              />
            </div>
          </div>

          {/* Budget */}
          <div className="space-y-2">
            <Label htmlFor="budget">Budget (Optional)</Label>
            <div className="relative">
              <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                id="budget"
                placeholder="e.g. $35/hour"
                value={formData.budget}
                onChange={(e) => setFormData({...formData, budget: e.target.value})}
                className="pl-10 bg-input-background border-0 rounded-xl"
              />
            </div>
          </div>

          {/* Special Requirements */}
          <div className="space-y-2">
            <Label htmlFor="requirements">Special Requirements</Label>
            <Textarea
              id="requirements"
              placeholder="Any specific requirements, accessibility needs, or preferences..."
              value={formData.requirements}
              onChange={(e) => setFormData({...formData, requirements: e.target.value})}
              className="bg-input-background border-0 rounded-xl"
              rows={3}
            />
          </div>

          {/* Additional Information */}
          <Card className="bg-blue-50 border-blue-200">
            <CardContent className="p-4">
              <p className="text-sm text-blue-800">
                <strong>Note:</strong> This is a recurring payment. This is not a one time payment.
              </p>
            </CardContent>
          </Card>

          {/* Submit Button */}
          <Button
            onClick={handleSubmit}
            disabled={!isFormValid}
            className="w-full bg-teal-dark hover:bg-teal text-white py-6 rounded-xl shadow-lg"
            size="lg"
          >
            Submit Request
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="bg-gradient-to-r from-sage to-teal px-6 py-8 pt-12">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-white text-2xl">My Support Requests</h1>
            <p className="text-white/90 text-sm">Manage your posted requests</p>
          </div>
          
          <Button
            onClick={() => setIsCreatingRequest(true)}
            className="bg-white/20 hover:bg-white/30 text-white border-0 rounded-full"
            size="sm"
          >
            <Plus className="w-5 h-5" />
          </Button>
        </div>
      </div>

      {/* Requests List */}
      <div className="px-6 py-6">
        {/* Empty State */}
        <div className="text-center py-20">
          <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
            <Plus className="w-10 h-10 text-muted-foreground" />
          </div>
          <h3 className="text-lg mb-2">No support requests yet</h3>
          <p className="text-muted-foreground text-sm mb-6">
            Create your first support request to start finding help.
          </p>
          <Button
            onClick={() => setIsCreatingRequest(true)}
            className="bg-teal-dark hover:bg-teal text-white"
          >
            <Plus className="w-4 h-4 mr-2" />
            Create Request
          </Button>
        </div>
      </div>
    </div>
  );
};