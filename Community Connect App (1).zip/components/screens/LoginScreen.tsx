import React, { useState } from 'react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { useAppContext, User } from '../AppContext';
import { ArrowLeft, Mail, Lock, Eye, EyeOff } from 'lucide-react';
import logoImage from 'figma:asset/7a73c8d9ce31fddbc3a6405c6568ae75f73b9430.png';

export const LoginScreen: React.FC = () => {
  const { setCurrentScreen, login } = useAppContext();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const handleLogin = () => {
    // Mock login - in real app would validate credentials
    const mockUser: User = {
      id: '1',
      name: 'Demo User',
      email: email,
      role: email.includes('worker') ? 'support-worker' : 'participant',
      suburb: 'Richmond',
    };
    
    login(mockUser);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-sage-light to-teal-light flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between px-6 py-4 pt-12">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setCurrentScreen('welcome')}
          className="text-white hover:bg-white/20 rounded-full p-2"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <h2 className="text-white">Welcome Back</h2>
        <div className="w-9" />
      </div>

      {/* Login Form */}
      <div className="flex-1 flex items-center justify-center px-6">
        <Card className="w-full max-w-sm bg-white/95 backdrop-blur-sm border-0 shadow-xl">
          <CardHeader className="text-center pb-6">
            {/* Logo */}
            <div className="w-20 h-20 mx-auto mb-4">
              <img 
                src={logoImage} 
                alt="Community Connect Logo" 
                className="w-full h-full object-contain rounded-[45px] m-[0px] p-[0px]"
              />
            </div>
            <CardTitle className="text-xl text-teal-dark">Log in to your account</CardTitle>
            <p className="text-muted-foreground text-sm">Don&apos;t have an account? Sign Up</p>
          </CardHeader>
          
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="inputEmail" className="text-sm">Email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  id="inputEmail"
                  type="email"
                  placeholder="Enter your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="pl-10 py-6 rounded-xl bg-input-background border-0"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="inputPassword" className="text-sm">Password</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  id="inputPassword"
                  type={showPassword ? 'text' : 'password'}
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pl-10 pr-10 py-6 rounded-xl bg-input-background border-0"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 p-0 h-auto hover:bg-transparent"
                >
                  {showPassword ? (
                    <EyeOff className="w-4 h-4 text-muted-foreground" />
                  ) : (
                    <Eye className="w-4 h-4 text-muted-foreground" />
                  )}
                </Button>
              </div>
            </div>

            <Button
              onClick={handleLogin}
              className="w-full bg-purple-700 hover:bg-purple-800 text-white py-6 rounded-xl shadow-lg"
              size="lg"
              disabled={!email || !password}
            >
              Log In
            </Button>

            <div className="text-center">
              <Button
                variant="link"
                onClick={() => setCurrentScreen('signup')}
                className="text-teal-dark hover:text-teal text-sm"
              >
                Don&apos;t have an account? Sign up
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Demo Hint */}
      <div className="px-6 py-4">
        <Card className="bg-white/90 border-0">
          <CardContent className="p-4">
            <p className="text-xs text-center text-muted-foreground">
              <strong>Demo:</strong> Use "participant@demo.com" or "worker@demo.com" with any password
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};