import React from 'react';
import { Button } from '../ui/button';
import { Card, CardContent } from '../ui/card';
import { useAppContext } from '../AppContext';
import { 
  User, 
  Home, 
  HelpCircle, 
  LogOut, 
  Settings, 
  Shield, 
  FileText, 
  Bell,
  ChevronRight 
} from 'lucide-react';

export const MenuScreen: React.FC = () => {
  const { user, logout, setCurrentScreen } = useAppContext();

  const handleLogout = () => {
    logout();
  };

  const menuItems = [
    {
      id: 'home',
      icon: Home,
      label: 'Return to Home',
      action: () => setCurrentScreen(user?.role === 'participant' ? 'participant-home' : 'support-worker-home'),
    },
    {
      id: 'profile',
      icon: User,
      label: 'Edit Profile',
      action: () => setCurrentScreen('edit-profile'),
    },
    {
      id: 'notifications',
      icon: Bell,
      label: 'Notifications',
      action: () => setCurrentScreen('notifications'),
    },
    {
      id: 'settings',
      icon: Settings,
      label: 'Settings',
      action: () => setCurrentScreen('settings'),
    },
    {
      id: 'privacy',
      icon: Shield,
      label: 'Privacy & Safety',
      action: () => setCurrentScreen('privacy'),
    },
    {
      id: 'help',
      icon: HelpCircle,
      label: 'Help & Support',
      action: () => setCurrentScreen('help'),
    },
    {
      id: 'terms',
      icon: FileText,
      label: 'Terms & Privacy Policy',
      action: () => setCurrentScreen('terms'),
    },
  ];

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="bg-gradient-to-r from-sage to-teal px-6 py-8 pt-12">
        <div className="flex items-center space-x-4">
          <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center">
            <User className="w-8 h-8 text-teal-dark" />
          </div>
          <div>
            <h1 className="text-white text-xl">{user?.name}</h1>
            <p className="text-white/90 text-sm capitalize">
              {user?.role?.replace('-', ' ')} • {user?.suburb}
            </p>
          </div>
        </div>
      </div>

      {/* Menu Items */}
      <div className="px-6 py-6">
        <Card className="border-0 shadow-sm">
          <CardContent className="p-0">
            {menuItems.map((item, index) => {
              const Icon = item.icon;
              const isLast = index === menuItems.length - 1;
              
              return (
                <Button
                  key={item.id}
                  variant="ghost"
                  onClick={item.action}
                  className={`w-full justify-start h-14 px-6 hover:bg-muted ${
                    !isLast ? 'border-b border-border' : ''
                  }`}
                >
                  <Icon className="w-5 h-5 mr-4 text-muted-foreground" />
                  <span className="flex-1 text-left">{item.label}</span>
                  <ChevronRight className="w-4 h-4 text-muted-foreground" />
                </Button>
              );
            })}
          </CardContent>
        </Card>

        {/* Logout Button */}
        <div className="mt-6">
          <Button
            onClick={handleLogout}
            variant="outline"
            className="w-full border-destructive text-destructive hover:bg-destructive hover:text-white h-14"
          >
            <LogOut className="w-5 h-5 mr-4" />
            Log Out
          </Button>
        </div>

        {/* App Info */}
        <div className="mt-8 text-center">
          <p className="text-muted-foreground text-sm">
            Community Connect v1.0.0
          </p>
          <p className="text-muted-foreground text-xs mt-1">
            Connecting hearts, building communities
          </p>
        </div>
      </div>
    </div>
  );
};