import React, { useState } from 'react';
import { Button } from '../ui/button';
import { Card, CardContent } from '../ui/card';
import { Badge } from '../ui/badge';
import { useAppContext } from '../AppContext';
import { ArrowLeft, Settings, Heart, MessageSquare, Calendar, User, Shield, CheckCircle2 } from 'lucide-react';

interface Notification {
  id: string;
  type: 'match' | 'message' | 'booking' | 'system' | 'verification';
  title: string;
  description: string;
  timestamp: Date;
  isRead: boolean;
  actionRequired?: boolean;
  profileImage?: string;
}

const mockNotifications: Notification[] = [
  {
    id: '1',
    type: 'match',
    title: 'New Match!',
    description: 'Sarah Mitchell is interested in your support request for grocery shopping.',
    timestamp: new Date(Date.now() - 5 * 60 * 1000), // 5 minutes ago
    isRead: false,
    profileImage: 'https://images.unsplash.com/photo-1494790108755-2616b612ca02?w=100&h=100&fit=crop&crop=face'
  },
  {
    id: '2',
    type: 'message',
    title: 'New Message',
    description: 'Alex Johnson: "Hi! I saw your profile and I\'m interested in..."',
    timestamp: new Date(Date.now() - 15 * 60 * 1000), // 15 minutes ago
    isRead: false,
    profileImage: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face'
  },
  {
    id: '3',
    type: 'booking',
    title: 'Booking Confirmed',
    description: 'Your support session with Emma Wilson on Tuesday at 10:00 AM has been confirmed.',
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
    isRead: false,
    actionRequired: true
  },
  {
    id: '4',
    type: 'system',
    title: 'Profile Views',
    description: 'Your profile has been viewed 12 times this week. Consider updating your bio to attract more matches.',
    timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000), // 4 hours ago
    isRead: true
  },
  {
    id: '5',
    type: 'verification',
    title: 'Verification Complete',
    description: 'Your Working with Children Check has been verified and approved.',
    timestamp: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000), // 1 day ago
    isRead: true
  },
  {
    id: '6',
    type: 'match',
    title: 'Support Request Responded',
    description: '3 support workers have responded to your "Personal Care Assistance" request.',
    timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), // 2 days ago
    isRead: true,
    actionRequired: true
  },
  {
    id: '7',
    type: 'message',
    title: 'New Message',
    description: 'Jessica Chen: "Thank you for the great support session yesterday!"',
    timestamp: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000), // 3 days ago
    isRead: true,
    profileImage: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face'
  }
];

export const NotificationsScreen: React.FC = () => {
  const { user, setCurrentScreen } = useAppContext();
  const [notifications, setNotifications] = useState<Notification[]>(mockNotifications);
  const [filter, setFilter] = useState<'all' | 'unread'>('all');

  const unreadCount = notifications.filter(n => !n.isRead).length;
  const filteredNotifications = filter === 'all' 
    ? notifications 
    : notifications.filter(n => !n.isRead);

  const markAsRead = (notificationId: string) => {
    setNotifications(prev => 
      prev.map(n => n.id === notificationId ? { ...n, isRead: true } : n)
    );
  };

  const markAllAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'match': return Heart;
      case 'message': return MessageSquare;
      case 'booking': return Calendar;
      case 'verification': return Shield;
      case 'system': return User;
      default: return User;
    }
  };

  const getIconColor = (type: string) => {
    switch (type) {
      case 'match': return 'text-red-500';
      case 'message': return 'text-blue-500';
      case 'booking': return 'text-green-500';
      case 'verification': return 'text-purple-500';
      case 'system': return 'text-orange-500';
      default: return 'text-gray-500';
    }
  };

  const formatTime = (date: Date) => {
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) {
      return 'Just now';
    } else if (diffInMinutes < 60) {
      return `${diffInMinutes}m ago`;
    } else if (diffInMinutes < 1440) {
      const hours = Math.floor(diffInMinutes / 60);
      return `${hours}h ago`;
    } else {
      const days = Math.floor(diffInMinutes / 1440);
      return `${days}d ago`;
    }
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="bg-gradient-to-r from-sage to-teal px-6 py-8 pt-12">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setCurrentScreen(user?.role === 'participant' ? 'participant-home' : 'support-worker-home')}
              className="text-white hover:bg-white/20 rounded-full p-2"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <h1 className="text-white text-2xl">Notifications</h1>
          </div>
          
          <div className="flex items-center space-x-2">
            {unreadCount > 0 && (
              <Button
                variant="ghost"
                size="sm"
                onClick={markAllAsRead}
                className="text-white hover:bg-white/20 text-xs px-3"
              >
                Mark all read
              </Button>
            )}
            <Button
              variant="ghost"
              size="sm"
              className="text-white hover:bg-white/20 rounded-full p-2"
            >
              <Settings className="w-5 h-5" />
            </Button>
          </div>
        </div>

        {/* Filter Tabs */}
        <div className="flex bg-white/20 rounded-xl p-1">
          <Button
            variant={filter === 'all' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setFilter('all')}
            className={`flex-1 ${filter === 'all' ? 'bg-white text-teal-dark' : 'text-white hover:bg-white/20'}`}
          >
            All ({notifications.length})
          </Button>
          <Button
            variant={filter === 'unread' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setFilter('unread')}
            className={`flex-1 ${filter === 'unread' ? 'bg-white text-teal-dark' : 'text-white hover:bg-white/20'}`}
          >
            Unread ({unreadCount})
          </Button>
        </div>
      </div>

      {/* Notifications List */}
      <div className="px-6 py-6">
        {filteredNotifications.length > 0 ? (
          <div className="space-y-3">
            {filteredNotifications.map((notification) => {
              const Icon = getNotificationIcon(notification.type);
              const iconColor = getIconColor(notification.type);
              
              return (
                <Card 
                  key={notification.id} 
                  className={`border-0 shadow-sm cursor-pointer hover:shadow-md transition-shadow ${
                    !notification.isRead ? 'bg-blue-50 border-l-4 border-l-blue-500' : ''
                  }`}
                  onClick={() => markAsRead(notification.id)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start space-x-4">
                      {/* Profile Image or Icon */}
                      <div className="relative">
                        {notification.profileImage ? (
                          <img
                            src={notification.profileImage}
                            alt="Profile"
                            className="w-12 h-12 rounded-full object-cover"
                          />
                        ) : (
                          <div className="w-12 h-12 bg-muted rounded-full flex items-center justify-center">
                            <Icon className={`w-6 h-6 ${iconColor}`} />
                          </div>
                        )}
                        
                        {/* Type indicator */}
                        <div className={`absolute -bottom-1 -right-1 w-6 h-6 rounded-full flex items-center justify-center ${
                          notification.type === 'match' ? 'bg-red-500' :
                          notification.type === 'message' ? 'bg-blue-500' :
                          notification.type === 'booking' ? 'bg-green-500' :
                          notification.type === 'verification' ? 'bg-purple-500' :
                          'bg-orange-500'
                        }`}>
                          <Icon className="w-3 h-3 text-white" />
                        </div>
                      </div>

                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <h4 className={`text-sm ${!notification.isRead ? 'font-medium' : ''}`}>
                              {notification.title}
                            </h4>
                            <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                              {notification.description}
                            </p>
                          </div>
                          
                          <div className="flex items-center space-x-2 ml-2">
                            <span className="text-xs text-muted-foreground whitespace-nowrap">
                              {formatTime(notification.timestamp)}
                            </span>
                            {!notification.isRead && (
                              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                            )}
                          </div>
                        </div>

                        {/* Action Required Badge */}
                        {notification.actionRequired && (
                          <div className="mt-2">
                            <Badge variant="outline" className="text-orange-600 border-orange-600 text-xs">
                              Action Required
                            </Badge>
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        ) : (
          /* Empty State */
          <div className="text-center py-20">
            <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle2 className="w-10 h-10 text-muted-foreground" />
            </div>
            <h3 className="text-lg mb-2">All caught up!</h3>
            <p className="text-muted-foreground text-sm">
              {filter === 'unread' 
                ? "You don't have any unread notifications."
                : "You don't have any notifications yet."
              }
            </p>
          </div>
        )}
      </div>
    </div>
  );
};