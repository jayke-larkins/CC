import React, { useState } from 'react';
import { Button } from '../ui/button';
import { Card, CardContent } from '../ui/card';
import { Badge } from '../ui/badge';
import { useAppContext } from '../AppContext';
import { mockSupportWorkers, SupportWorker } from '../MockData';
import { Heart, MessageSquare, MapPin, Clock, Shield, X, RotateCcw, Menu, Bell } from 'lucide-react';

export const ParticipantHomeScreen: React.FC = () => {
  const { setCurrentScreen, user } = useAppContext();
  const [currentWorkerIndex, setCurrentWorkerIndex] = useState(0);
  const [swipedWorkers, setSwipedWorkers] = useState<string[]>([]);

  const availableWorkers = mockSupportWorkers.filter(
    worker => !swipedWorkers.includes(worker.id)
  );

  const currentWorker = availableWorkers[currentWorkerIndex];

  const handleSwipe = (workerId: string, action: 'like' | 'pass') => {
    setSwipedWorkers(prev => [...prev, workerId]);
    
    if (currentWorkerIndex < availableWorkers.length - 1) {
      setCurrentWorkerIndex(prev => prev + 1);
    } else {
      setCurrentWorkerIndex(0);
    }
  };

  const handleUndo = () => {
    if (swipedWorkers.length > 0) {
      const lastSwipedId = swipedWorkers[swipedWorkers.length - 1];
      setSwipedWorkers(prev => prev.slice(0, -1));
      
      const lastWorkerIndex = mockSupportWorkers.findIndex(w => w.id === lastSwipedId);
      setCurrentWorkerIndex(Math.max(0, lastWorkerIndex));
    }
  };

  const handleViewProfile = (worker: SupportWorker) => {
    setCurrentScreen('worker-profile-view');
    // In a real app, you'd pass the worker data to the profile view
  };

  const handleMessage = (worker: SupportWorker) => {
    setCurrentScreen('chat');
    // In a real app, you'd start a conversation with this worker
  };

  if (!currentWorker) {
    return (
      <div className="min-h-screen bg-background pb-20">
        {/* Header */}
        <div className="bg-gradient-to-r from-sage to-teal px-6 py-8 pt-12">
          <div className="flex items-center justify-between mb-4">
            <div className="flex-1">
              <h1 className="text-white text-2xl">Hello, {user?.name?.split(' ')[0]}</h1>
              <p className="text-white/90 text-sm">Find your perfect support worker</p>
            </div>
            
            {/* Top Right Actions */}
            <div className="flex items-center space-x-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setCurrentScreen('notifications')}
                className="text-white hover:bg-white/20 rounded-full p-2 relative"
              >
                <Bell className="w-5 h-5" />
                {/* Notification Badge */}
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full"></div>
              </Button>
              
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setCurrentScreen('menu')}
                className="text-white hover:bg-white/20 rounded-full p-2"
              >
                <Menu className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>

        {/* No more workers */}
        <div className="flex-1 flex items-center justify-center px-6">
          <div className="text-center">
            <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
              <Heart className="w-10 h-10 text-muted-foreground" />
            </div>
            <h3 className="text-lg mb-2">You&apos;ve seen everyone!</h3>
            <p className="text-muted-foreground text-sm mb-6">
              Check back later for new support workers in your area.
            </p>
            <Button
              onClick={() => {
                setSwipedWorkers([]);
                setCurrentWorkerIndex(0);
              }}
              variant="outline"
              className="w-full"
            >
              <RotateCcw className="w-4 h-4 mr-2" />
              Start Over
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="bg-gradient-to-r from-sage to-teal px-6 py-8 pt-12">
        <div className="flex items-center justify-between mb-4">
          <div className="flex-1">
            <h1 className="text-white text-2xl">Hello, {user?.name?.split(' ')[0]}</h1>
            <p className="text-white/90 text-sm">Find your perfect support worker</p>
          </div>
          
          {/* Top Right Actions */}
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setCurrentScreen('notifications')}
              className="text-white hover:bg-white/20 rounded-full p-2 relative"
            >
              <Bell className="w-5 h-5" />
              {/* Notification Badge */}
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full"></div>
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setCurrentScreen('menu')}
              className="text-white hover:bg-white/20 rounded-full p-2"
            >
              <Menu className="w-5 h-5" />
            </Button>
          </div>
        </div>
        
        <div className="text-white text-sm">
          {availableWorkers.length - currentWorkerIndex} left
        </div>
      </div>

      {/* Worker Card */}
      <div className="px-6 -mt-8">
        <Card className="bg-white shadow-xl border-0 overflow-hidden">
          {/* Profile Image */}
          <div className="relative h-64 bg-gradient-to-br from-sage-light to-teal-light">
            <img
              src={currentWorker.profileImage}
              alt={currentWorker.name}
              className="w-full h-full object-cover"
            />
            
            {/* Online Indicator */}
            {currentWorker.isOnline && (
              <div className="absolute top-4 right-4">
                <div className="w-4 h-4 bg-green-500 rounded-full border-2 border-white"></div>
              </div>
            )}

            {/* Badges */}
            <div className="absolute bottom-4 left-4 flex gap-2">
              {currentWorker.isVerified && (
                <Badge className="bg-green-500 text-white border-0">
                  <Shield className="w-3 h-3 mr-1" />
                  Verified
                </Badge>
              )}
              {currentWorker.isNDISExperienced && (
                <Badge className="bg-blue-500 text-white border-0">
                  NDIS
                </Badge>
              )}
              {currentWorker.isOnline && (
                <Badge className="bg-green-500 text-white border-0">
                  Available
                </Badge>
              )}
            </div>
          </div>

          <CardContent className="p-6">
            {/* Name and Location */}
            <div className="mb-4">
              <h2 className="text-2xl mb-1">{currentWorker.name}</h2>
              <div className="flex items-center text-muted-foreground text-sm mb-2">
                <MapPin className="w-4 h-4 mr-1" />
                {currentWorker.suburb}
              </div>
              <div className="flex items-center text-muted-foreground text-sm">
                <Clock className="w-4 h-4 mr-1" />
                {currentWorker.yearsExperience} years experience
              </div>
            </div>

            {/* Tagline */}
            <p className="text-muted-foreground mb-6">{currentWorker.tagline}</p>

            {/* Action Buttons */}
            <div className="flex gap-3">
              <Button
                onClick={() => handleSwipe(currentWorker.id, 'pass')}
                variant="outline"
                size="lg"
                className="flex-1 border-destructive text-destructive hover:bg-destructive hover:text-white"
              >
                <X className="w-5 h-5 mr-2" />
                Pass
              </Button>
              
              <Button
                onClick={() => handleMessage(currentWorker)}
                variant="outline"
                size="lg"
                className="px-4"
              >
                <MessageSquare className="w-5 h-5" />
              </Button>
              
              <Button
                onClick={() => handleSwipe(currentWorker.id, 'like')}
                size="lg"
                className="flex-1 bg-teal-dark hover:bg-teal text-white"
              >
                <Heart className="w-5 h-5 mr-2" />
                Interested
              </Button>
            </div>

            {/* Secondary Actions */}
            <div className="flex gap-3 mt-3">
              <Button
                onClick={() => handleViewProfile(currentWorker)}
                variant="ghost"
                size="sm"
                className="flex-1 text-teal-dark hover:text-teal"
              >
                View Full Profile
              </Button>
              
              {swipedWorkers.length > 0 && (
                <Button
                  onClick={handleUndo}
                  variant="ghost"
                  size="sm"
                  className="px-4 text-muted-foreground"
                >
                  <RotateCcw className="w-4 h-4" />
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};