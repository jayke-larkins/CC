import React, { useState } from 'react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { Progress } from '../ui/progress';
import { useAppContext } from '../AppContext';
import { 
  User, 
  Camera, 
  MapPin, 
  Calendar, 
  Heart,
  FileText,
  Target,
  ChevronRight,
  Bell,
  Edit3
} from 'lucide-react';

export const ParticipantProfileScreen: React.FC = () => {
  const { user, setCurrentScreen } = useAppContext();
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: user?.name || '',
    location: user?.suburb || 'Richmond',
    age: '32',
    interests: 'Reading, gardening, cooking, community events, swimming',
    bio: 'Hi! I&apos;m looking for reliable support workers to help me maintain my independence. I enjoy staying active in my community and appreciate workers who are patient and understanding.',
  });

  // Mock data for profile completion
  const profileFields = ['Photo', 'Location', 'Age', 'Interests', 'Bio'];
  const completedFields = [formData.location, formData.age, formData.interests, formData.bio].filter(field => field).length + 1; // +1 for name
  const profileCompletion = Math.round((completedFields / profileFields.length) * 100);

  const myActivityItems = [
    { 
      id: 'saved-workers', 
      icon: Heart, 
      label: 'Saved Workers', 
      count: '3 saved',
      description: 'Support workers you&apos;ve shown interest in'
    },
    { 
      id: 'support-requests', 
      icon: FileText, 
      label: 'My Support Requests', 
      count: '2 active',
      description: 'Your posted job requests and their status'
    },
    { 
      id: 'ndis-goals', 
      icon: Target, 
      label: 'NDIS Goals (Optional)', 
      count: 'Not set',
      description: 'Track your NDIS plan goals and progress'
    },
  ];

  const handleSave = () => {
    setIsEditing(false);
    // In real app, save to backend
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="bg-gradient-to-r from-sage to-teal px-6 py-8 pt-12">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setCurrentScreen('notifications')}
              className="text-white hover:bg-white/20 rounded-full p-2 relative"
            >
              <Bell className="w-5 h-5" />
              {/* Notification Badge */}
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full"></div>
            </Button>
            
            <h1 className="text-white text-2xl">Profile</h1>
          </div>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsEditing(!isEditing)}
            className="text-white hover:bg-white/20 rounded-full p-2"
          >
            <Edit3 className="w-5 h-5" />
          </Button>
        </div>

        {/* Profile Card */}
        <Card className="bg-white/95 backdrop-blur-sm border-0 shadow-xl">
          <CardContent className="p-6">
            {/* Profile Picture Section */}
            <div className="flex items-center space-x-4 mb-4">
              <div className="relative">
                <div className="w-20 h-20 bg-gradient-to-br from-sage-light to-teal-light rounded-full flex items-center justify-center">
                  <User className="w-10 h-10 text-white" />
                </div>
                {isEditing && (
                  <Button
                    size="sm"
                    className="absolute -bottom-2 -right-2 w-8 h-8 rounded-full bg-teal-dark hover:bg-teal p-0"
                  >
                    <Camera className="w-4 h-4" />
                  </Button>
                )}
              </div>
              
              <div className="flex-1">
                {isEditing ? (
                  <Input
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    className="text-lg mb-2"
                  />
                ) : (
                  <h2 className="text-xl mb-1">{formData.name}</h2>
                )}
                <div className="flex items-center text-muted-foreground text-sm mb-2">
                  <MapPin className="w-4 h-4 mr-1" />
                  {isEditing ? (
                    <Input
                      value={formData.location}
                      onChange={(e) => setFormData({...formData, location: e.target.value})}
                      className="text-sm h-8"
                    />
                  ) : (
                    formData.location
                  )}
                </div>
                <p className="text-muted-foreground text-sm">Participant</p>
              </div>
            </div>

            {/* Profile Details */}
            <div className="space-y-4">
              <div>
                <Label className="text-xs text-muted-foreground">Age</Label>
                {isEditing ? (
                  <Input
                    value={formData.age}
                    onChange={(e) => setFormData({...formData, age: e.target.value})}
                    className="mt-1"
                  />
                ) : (
                  <p className="text-sm">{formData.age}</p>
                )}
              </div>

              <div>
                <Label className="text-xs text-muted-foreground">Interests/Hobbies</Label>
                {isEditing ? (
                  <Textarea
                    value={formData.interests}
                    onChange={(e) => setFormData({...formData, interests: e.target.value})}
                    className="mt-1"
                    rows={2}
                  />
                ) : (
                  <p className="text-sm">{formData.interests}</p>
                )}
              </div>

              <div>
                <Label className="text-xs text-muted-foreground">Bio</Label>
                {isEditing ? (
                  <Textarea
                    value={formData.bio}
                    onChange={(e) => setFormData({...formData, bio: e.target.value})}
                    className="mt-1"
                    rows={3}
                  />
                ) : (
                  <p className="text-sm">{formData.bio}</p>
                )}
              </div>
            </div>

            {isEditing && (
              <div className="flex gap-2 mt-4">
                <Button onClick={handleSave} className="flex-1 bg-teal-dark hover:bg-teal">
                  Save Changes
                </Button>
                <Button onClick={() => setIsEditing(false)} variant="outline" className="flex-1">
                  Cancel
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Profile Completion Tracker */}
      <div className="px-6 py-6">
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base">Profile Completion</CardTitle>
              <div className="flex items-center space-x-2">
                <Bell className="w-4 h-4 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">{completedFields}/{profileFields.length}</span>
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-0">
            <Progress value={profileCompletion} className="mb-3" />
            <p className="text-xs text-muted-foreground">
              Complete your profile to get better matches with support workers
            </p>
          </CardContent>
        </Card>
      </div>

      {/* My Activity */}
      <div className="px-6 pb-6">
        <h3 className="text-lg mb-4">My Activity</h3>
        
        <Card className="border-0 shadow-sm">
          <CardContent className="p-0">
            {myActivityItems.map((item, index) => {
              const Icon = item.icon;
              const isLast = index === myActivityItems.length - 1;
              
              return (
                <Button
                  key={item.id}
                  variant="ghost"
                  onClick={() => {
                    if (item.id === 'saved-workers') {
                      setCurrentScreen('saved-workers');
                    } else if (item.id === 'support-requests') {
                      setCurrentScreen('job-requests');
                    } else if (item.id === 'ndis-goals') {
                      setCurrentScreen('ndis-goals');
                    }
                  }}
                  className={`w-full justify-start h-16 px-6 hover:bg-muted ${
                    !isLast ? 'border-b border-border' : ''
                  }`}
                >
                  <Icon className="w-5 h-5 mr-4 text-muted-foreground" />
                  <div className="flex-1 text-left">
                    <div className="text-sm">{item.label}</div>
                    <div className="text-xs text-muted-foreground">
                      {item.count} • {item.description}
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-muted-foreground" />
                </Button>
              );
            })}
          </CardContent>
        </Card>

        {/* Account Status */}
        <Card className="mt-4 border-0 shadow-sm bg-green-50">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="w-3 h-3 bg-green-500 rounded-full"></div>
              <div>
                <p className="text-sm">Account Status: <strong>Active</strong></p>
                <p className="text-xs text-muted-foreground">Your profile is visible to support workers</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};