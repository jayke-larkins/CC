import React, { useState } from 'react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { useAppContext } from '../AppContext';
import { 
  ArrowLeft, 
  FileText, 
  Download, 
  Eye, 
  Plus,
  Search,
  Filter,
  Calendar,
  DollarSign,
  ClipboardList
} from 'lucide-react';
import { Input } from '../ui/input';

interface DocumentTemplate {
  id: string;
  name: string;
  category: 'invoice' | 'agreement' | 'progress' | 'assessment';
  description: string;
  lastUsed?: Date;
  timesUsed: number;
  isFavorite: boolean;
}

const mockTemplates: DocumentTemplate[] = [
  {
    id: '1',
    name: 'Standard Invoice Template',
    category: 'invoice',
    description: 'Professional invoice template for NDIS services with GST calculations',
    lastUsed: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
    timesUsed: 45,
    isFavorite: true
  },
  {
    id: '2',
    name: 'Service Agreement Template',
    category: 'agreement',
    description: 'Comprehensive service agreement covering scope, rates, and expectations',
    lastUsed: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
    timesUsed: 12,
    isFavorite: true
  },
  {
    id: '3',
    name: 'Daily Progress Notes',
    category: 'progress',
    description: 'Structured template for recording daily support activities and outcomes',
    lastUsed: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
    timesUsed: 89,
    isFavorite: false
  },
  {
    id: '4',
    name: 'Weekly Progress Summary',
    category: 'progress',
    description: 'Comprehensive weekly summary of participant progress and goals',
    lastUsed: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
    timesUsed: 23,
    isFavorite: false
  },
  {
    id: '5',
    name: 'Initial Assessment Form',
    category: 'assessment',
    description: 'Comprehensive assessment form for new participants',
    lastUsed: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000),
    timesUsed: 8,
    isFavorite: false
  },
  {
    id: '6',
    name: 'Monthly Invoice Summary',
    category: 'invoice',
    description: 'Consolidated monthly invoice for regular clients',
    lastUsed: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
    timesUsed: 15,
    isFavorite: true
  }
];

export const ReportingTemplatesScreen: React.FC = () => {
  const { setCurrentScreen } = useAppContext();
  const [templates, setTemplates] = useState<DocumentTemplate[]>(mockTemplates);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const categories = [
    { id: 'all', label: 'All Templates', icon: FileText, count: templates.length },
    { id: 'invoice', label: 'Invoices', icon: DollarSign, count: templates.filter(t => t.category === 'invoice').length },
    { id: 'agreement', label: 'Service Agreements', icon: FileText, count: templates.filter(t => t.category === 'agreement').length },
    { id: 'progress', label: 'Progress Notes', icon: ClipboardList, count: templates.filter(t => t.category === 'progress').length },
    { id: 'assessment', label: 'Assessments', icon: Calendar, count: templates.filter(t => t.category === 'assessment').length },
  ];

  const filteredTemplates = templates.filter(template => {
    const matchesSearch = template.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         template.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || template.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleUseTemplate = (templateId: string) => {
    // Update usage count
    setTemplates(prev => prev.map(t => 
      t.id === templateId 
        ? { ...t, timesUsed: t.timesUsed + 1, lastUsed: new Date() }
        : t
    ));
    alert(`Using template ${templateId} - would open template editor`);
  };

  const handleDownload = (templateId: string) => {
    alert(`Downloading template ${templateId} - would generate download`);
  };

  const handlePreview = (templateId: string) => {
    alert(`Previewing template ${templateId} - would show template preview`);
  };

  const toggleFavorite = (templateId: string) => {
    setTemplates(prev => prev.map(t => 
      t.id === templateId ? { ...t, isFavorite: !t.isFavorite } : t
    ));
  };

  const formatLastUsed = (date?: Date) => {
    if (!date) return 'Never used';
    
    const now = new Date();
    const diffInDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24));
    
    if (diffInDays === 0) {
      return 'Used today';
    } else if (diffInDays === 1) {
      return 'Used yesterday';
    } else if (diffInDays < 7) {
      return `Used ${diffInDays} days ago`;
    } else if (diffInDays < 30) {
      const weeks = Math.floor(diffInDays / 7);
      return `Used ${weeks} week${weeks > 1 ? 's' : ''} ago`;
    } else {
      const months = Math.floor(diffInDays / 30);
      return `Used ${months} month${months > 1 ? 's' : ''} ago`;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'invoice': return 'bg-green-100 text-green-800';
      case 'agreement': return 'bg-blue-100 text-blue-800';
      case 'progress': return 'bg-purple-100 text-purple-800';
      case 'assessment': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="bg-gradient-to-r from-sage to-teal px-6 py-8 pt-12">
        <div className="flex items-center mb-6">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setCurrentScreen('worker-profile')}
            className="text-white hover:bg-white/20 rounded-full p-2 mr-3"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-white text-2xl">Reporting Templates</h1>
            <p className="text-white/90 text-sm">Professional document templates for your work</p>
          </div>
        </div>

        {/* Search */}
        <div className="relative mb-4">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search templates..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 bg-white/90 border-0 rounded-xl"
          />
        </div>

        {/* Quick Actions */}
        <div className="flex gap-3">
          <Button 
            className="bg-white/20 hover:bg-white/30 text-white border-0 flex-1"
            size="sm"
          >
            <Plus className="w-4 h-4 mr-2" />
            Create Custom
          </Button>
          <Button 
            variant="outline"
            className="border-white/30 text-white hover:bg-white/20"
            size="sm"
          >
            <Filter className="w-4 h-4 mr-2" />
            Filter
          </Button>
        </div>
      </div>

      {/* Category Tabs */}
      <div className="px-6 py-4 border-b border-border">
        <div className="flex gap-2 overflow-x-auto pb-2">
          {categories.map((category) => {
            const Icon = category.icon;
            return (
              <Button
                key={category.id}
                variant={selectedCategory === category.id ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedCategory(category.id)}
                className={`whitespace-nowrap ${
                  selectedCategory === category.id 
                    ? 'bg-teal-dark text-white' 
                    : 'text-muted-foreground'
                }`}
              >
                <Icon className="w-4 h-4 mr-2" />
                {category.label} ({category.count})
              </Button>
            );
          })}
        </div>
      </div>

      {/* Templates Grid */}
      <div className="px-6 py-6">
        {filteredTemplates.length > 0 ? (
          <div className="space-y-4">
            {filteredTemplates.map((template) => (
              <Card key={template.id} className="border-0 shadow-sm hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <h3 className="text-lg">{template.name}</h3>
                        <Badge className={`text-xs ${getCategoryColor(template.category)}`}>
                          {template.category}
                        </Badge>
                        {template.isFavorite && (
                          <Badge variant="outline" className="text-yellow-600 border-yellow-600 text-xs">
                            ★ Favorite
                          </Badge>
                        )}
                      </div>
                      
                      <p className="text-sm text-muted-foreground mb-3">
                        {template.description}
                      </p>

                      <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                        <span>Used {template.timesUsed} times</span>
                        <span>•</span>
                        <span>{formatLastUsed(template.lastUsed)}</span>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex flex-col gap-2 ml-4">
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          onClick={() => handlePreview(template.id)}
                          variant="outline"
                          className="px-3"
                        >
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button
                          size="sm"
                          onClick={() => handleDownload(template.id)}
                          variant="outline"
                          className="px-3"
                        >
                          <Download className="w-4 h-4" />
                        </Button>
                      </div>
                      
                      <Button
                        size="sm"
                        onClick={() => handleUseTemplate(template.id)}
                        className="bg-teal-dark hover:bg-teal text-white"
                      >
                        Use Template
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          /* Empty State */
          <div className="text-center py-20">
            <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
              <FileText className="w-10 h-10 text-muted-foreground" />
            </div>
            <h3 className="text-lg mb-2">No templates found</h3>
            <p className="text-muted-foreground text-sm mb-6">
              {searchQuery ? 'Try adjusting your search terms.' : 'Create your first template to get started.'}
            </p>
            <Button className="bg-teal-dark hover:bg-teal text-white">
              <Plus className="w-4 h-4 mr-2" />
              Create Template
            </Button>
          </div>
        )}
      </div>

      {/* Template Categories Info */}
      <div className="px-6 pb-6">
        <Card className="bg-blue-50 border-blue-200">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Template Categories</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <strong>Invoices:</strong> Professional billing documents
              </div>
              <div>
                <strong>Service Agreements:</strong> Contract templates
              </div>
              <div>
                <strong>Progress Notes:</strong> Activity documentation
              </div>
              <div>
                <strong>Assessments:</strong> Evaluation forms
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};