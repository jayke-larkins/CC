import React, { useState } from 'react';
import { Button } from '../ui/button';
import { Card, CardContent } from '../ui/card';
import { Badge } from '../ui/badge';
import { useAppContext } from '../AppContext';
import { ArrowLeft, Heart, MessageSquare, MapPin, Clock, Shield, Star, Filter } from 'lucide-react';

interface SavedWorker {
  id: string;
  name: string;
  profileImage: string;
  suburb: string;
  yearsExperience: number;
  specialties: string[];
  rating: number;
  reviewCount: number;
  hourlyRate: string;
  isOnline: boolean;
  isVerified: boolean;
  savedDate: Date;
  lastActive: string;
}

const mockSavedWorkers: SavedWorker[] = [
  {
    id: '1',
    name: 'Sarah Mitchell',
    profileImage: 'https://images.unsplash.com/photo-1494790108755-2616b612ca02?w=400&h=400&fit=crop&crop=face',
    suburb: 'Richmond',
    yearsExperience: 5,
    specialties: ['Personal Care', 'Daily Living', 'Transport'],
    rating: 4.9,
    reviewCount: 127,
    hourlyRate: '$35-45',
    isOnline: true,
    isVerified: true,
    savedDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), // 2 days ago
    lastActive: 'Active now'
  },
  {
    id: '2',
    name: 'Michael Chen',
    profileImage: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=face',
    suburb: 'South Yarra',
    yearsExperience: 3,
    specialties: ['Recreation', 'Community Participation', 'Social Support'],
    rating: 4.8,
    reviewCount: 89,
    hourlyRate: '$32-40',
    isOnline: false,
    isVerified: true,
    savedDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000), // 5 days ago
    lastActive: '2 hours ago'
  },
  {
    id: '3',
    name: 'Emma Rodriguez',
    profileImage: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop&crop=face',
    suburb: 'Brunswick',
    yearsExperience: 7,
    specialties: ['Personal Care', 'Household Tasks', 'Medical Support'],
    rating: 5.0,
    reviewCount: 203,
    hourlyRate: '$40-50',
    isOnline: true,
    isVerified: true,
    savedDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), // 1 week ago
    lastActive: 'Active now'
  }
];

export const SavedWorkersScreen: React.FC = () => {
  const { setCurrentScreen } = useAppContext();
  const [savedWorkers, setSavedWorkers] = useState<SavedWorker[]>(mockSavedWorkers);
  const [sortBy, setSortBy] = useState<'recent' | 'rating' | 'availability'>('recent');

  const handleUnsave = (workerId: string) => {
    setSavedWorkers(prev => prev.filter(worker => worker.id !== workerId));
  };

  const handleMessage = (worker: SavedWorker) => {
    setCurrentScreen('chat');
    // In real app, would open chat with this worker
  };

  const handleViewProfile = (worker: SavedWorker) => {
    setCurrentScreen('worker-profile-view');
    // In real app, would show worker's full profile
  };

  const sortedWorkers = [...savedWorkers].sort((a, b) => {
    switch (sortBy) {
      case 'rating':
        return b.rating - a.rating;
      case 'availability':
        return (b.isOnline ? 1 : 0) - (a.isOnline ? 1 : 0);
      case 'recent':
      default:
        return b.savedDate.getTime() - a.savedDate.getTime();
    }
  });

  const formatSavedDate = (date: Date) => {
    const now = new Date();
    const diffInDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24));
    
    if (diffInDays === 0) {
      return 'Saved today';
    } else if (diffInDays === 1) {
      return 'Saved yesterday';
    } else if (diffInDays < 7) {
      return `Saved ${diffInDays} days ago`;
    } else {
      return `Saved ${Math.floor(diffInDays / 7)} week${Math.floor(diffInDays / 7) > 1 ? 's' : ''} ago`;
    }
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="bg-gradient-to-r from-sage to-teal px-6 py-8 pt-12">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setCurrentScreen('participant-profile')}
              className="text-white hover:bg-white/20 rounded-full p-2"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-white text-2xl">Saved Workers</h1>
              <p className="text-white/90 text-sm">{savedWorkers.length} support workers saved</p>
            </div>
          </div>
          
          <Button
            variant="ghost"
            size="sm"
            className="text-white hover:bg-white/20 rounded-full p-2"
          >
            <Filter className="w-5 h-5" />
          </Button>
        </div>

        {/* Sort Options */}
        <div className="flex gap-2 overflow-x-auto pb-2">
          {[
            { id: 'recent', label: 'Recently Saved' },
            { id: 'rating', label: 'Highest Rated' },
            { id: 'availability', label: 'Available Now' }
          ].map((option) => (
            <Button
              key={option.id}
              variant={sortBy === option.id ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSortBy(option.id as any)}
              className={`whitespace-nowrap ${
                sortBy === option.id 
                  ? 'bg-white text-teal-dark' 
                  : 'text-white border-white/30 hover:bg-white/20'
              }`}
            >
              {option.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Workers List */}
      <div className="px-6 py-6">
        {sortedWorkers.length > 0 ? (
          <div className="space-y-4">
            {sortedWorkers.map((worker) => (
              <Card key={worker.id} className="border-0 shadow-sm hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-4">
                    {/* Profile Image */}
                    <div className="relative">
                      <img
                        src={worker.profileImage}
                        alt={worker.name}
                        className="w-16 h-16 rounded-full object-cover"
                      />
                      {worker.isOnline && (
                        <div className="absolute bottom-0 right-0 w-4 h-4 bg-green-500 rounded-full border-2 border-white"></div>
                      )}
                    </div>

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h3 className="text-lg mb-1">{worker.name}</h3>
                          <div className="flex items-center text-muted-foreground text-sm mb-1">
                            <MapPin className="w-4 h-4 mr-1" />
                            {worker.suburb}
                          </div>
                          <div className="flex items-center text-muted-foreground text-sm">
                            <Clock className="w-4 h-4 mr-1" />
                            {worker.yearsExperience} years experience
                          </div>
                        </div>

                        <Button
                          onClick={() => handleUnsave(worker.id)}
                          variant="ghost"
                          size="sm"
                          className="text-red-500 hover:bg-red-50 p-2"
                        >
                          <Heart className="w-5 h-5 fill-current" />
                        </Button>
                      </div>

                      {/* Rating and Verification */}
                      <div className="flex items-center space-x-3 mb-3">
                        <div className="flex items-center">
                          <Star className="w-4 h-4 text-yellow-500 fill-current mr-1" />
                          <span className="text-sm">{worker.rating}</span>
                          <span className="text-xs text-muted-foreground ml-1">
                            ({worker.reviewCount} reviews)
                          </span>
                        </div>
                        
                        {worker.isVerified && (
                          <Badge variant="outline" className="text-green-600 border-green-600 text-xs">
                            <Shield className="w-3 h-3 mr-1" />
                            Verified
                          </Badge>
                        )}
                      </div>

                      {/* Specialties */}
                      <div className="flex flex-wrap gap-1 mb-3">
                        {worker.specialties.slice(0, 3).map((specialty) => (
                          <Badge key={specialty} variant="secondary" className="text-xs">
                            {specialty}
                          </Badge>
                        ))}
                        {worker.specialties.length > 3 && (
                          <Badge variant="secondary" className="text-xs">
                            +{worker.specialties.length - 3} more
                          </Badge>
                        )}
                      </div>

                      {/* Footer */}
                      <div className="flex items-center justify-between">
                        <div className="text-sm text-muted-foreground">
                          <div>{worker.hourlyRate}/hour • {worker.lastActive}</div>
                          <div className="text-xs">{formatSavedDate(worker.savedDate)}</div>
                        </div>

                        <div className="flex gap-2">
                          <Button
                            onClick={() => handleViewProfile(worker)}
                            variant="outline"
                            size="sm"
                          >
                            View Profile
                          </Button>
                          <Button
                            onClick={() => handleMessage(worker)}
                            size="sm"
                            className="bg-teal-dark hover:bg-teal text-white"
                          >
                            <MessageSquare className="w-4 h-4 mr-1" />
                            Message
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          /* Empty State */
          <div className="text-center py-20">
            <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
              <Heart className="w-10 h-10 text-muted-foreground" />
            </div>
            <h3 className="text-lg mb-2">No saved workers yet</h3>
            <p className="text-muted-foreground text-sm mb-6">
              When you find support workers you like, save them here for easy access.
            </p>
            <Button
              onClick={() => setCurrentScreen('participant-home')}
              className="bg-teal-dark hover:bg-teal text-white"
            >
              Browse Support Workers
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};