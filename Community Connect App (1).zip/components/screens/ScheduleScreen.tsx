import React, { useState } from 'react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { useAppContext } from '../AppContext';
import { Calendar, ChevronLeft, ChevronRight, Upload, Clock, MapPin, User, Plus, FileText } from 'lucide-react';

interface ScheduleItem {
  id: string;
  title: string;
  client: string;
  date: string;
  time: string;
  duration: string;
  location: string;
  type: 'shift' | 'appointment';
  status: 'confirmed' | 'pending' | 'completed';
}

const mockScheduleItems: ScheduleItem[] = [
  {
    id: '1',
    title: 'Personal Care Support',
    client: 'Alex Johnson',
    date: '2025-01-25',
    time: '09:00 AM',
    duration: '2 hours',
    location: 'Richmond',
    type: 'shift',
    status: 'confirmed',
  },
  {
    id: '2',
    title: 'Grocery Shopping',
    client: 'Jordan Smith',
    date: '2025-01-25',
    time: '02:00 PM',
    duration: '1.5 hours',
    location: 'Brunswick Mall',
    type: 'shift',
    status: 'confirmed',
  },
  {
    id: '3',
    title: 'Medical Appointment',
    client: 'Casey Williams',
    date: '2025-01-26',
    time: '11:30 AM',
    duration: '3 hours',
    location: 'Royal Melbourne Hospital',
    type: 'appointment',
    status: 'pending',
  },
];

export const ScheduleScreen: React.FC = () => {
  const { user } = useAppContext();
  const [currentDate, setCurrentDate] = useState(new Date());
  const [view, setView] = useState<'monthly' | 'weekly'>('weekly');

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-AU', { 
      month: 'long', 
      year: 'numeric' 
    });
  };

  const getWeekDates = (date: Date) => {
    const week = [];
    const startOfWeek = new Date(date);
    startOfWeek.setDate(date.getDate() - date.getDay());
    
    for (let i = 0; i < 7; i++) {
      const day = new Date(startOfWeek);
      day.setDate(startOfWeek.getDate() + i);
      week.push(day);
    }
    return week;
  };

  const navigateDate = (direction: 'prev' | 'next') => {
    const newDate = new Date(currentDate);
    if (view === 'monthly') {
      newDate.setMonth(currentDate.getMonth() + (direction === 'next' ? 1 : -1));
    } else {
      newDate.setDate(currentDate.getDate() + (direction === 'next' ? 7 : -7));
    }
    setCurrentDate(newDate);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed': return 'bg-green-500';
      case 'pending': return 'bg-yellow-500';
      case 'completed': return 'bg-gray-500';
      default: return 'bg-blue-500';
    }
  };

  const todaysItems = mockScheduleItems.filter(item => {
    const itemDate = new Date(item.date);
    const today = new Date();
    return itemDate.toDateString() === today.toDateString();
  });

  const handleExportReports = () => {
    alert('Export functionality would generate progress notes and schedule reports here.');
  };

  const handleCreateTemplate = () => {
    alert('Creating client template - would open template builder.');
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="bg-gradient-to-r from-sage to-teal px-6 py-8 pt-12">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-white text-2xl">Schedule</h1>
            <p className="text-white/90 text-sm">Manage your shifts and appointments</p>
          </div>
          
          {/* Upload/Export Button */}
          <Button
            variant="ghost"
            size="sm"
            onClick={handleExportReports}
            className="text-white hover:bg-white/20 rounded-full p-2"
            title="Export Reports"
          >
            <Upload className="w-5 h-5" />
          </Button>
        </div>

        {/* View Toggle */}
        <div className="flex bg-white/20 rounded-xl p-1">
          <Button
            variant={view === 'weekly' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setView('weekly')}
            className={`flex-1 ${view === 'weekly' ? 'bg-white text-teal-dark' : 'text-white hover:bg-white/20'}`}
          >
            Weekly
          </Button>
          <Button
            variant={view === 'monthly' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setView('monthly')}
            className={`flex-1 ${view === 'monthly' ? 'bg-white text-teal-dark' : 'text-white hover:bg-white/20'}`}
          >
            Monthly
          </Button>
        </div>
      </div>

      {/* Calendar Navigation */}
      <div className="px-6 py-4 border-b border-border">
        <div className="flex items-center justify-between">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigateDate('prev')}
            className="p-2"
          >
            <ChevronLeft className="w-5 h-5" />
          </Button>
          
          <h2 className="text-lg">{formatDate(currentDate)}</h2>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigateDate('next')}
            className="p-2"
          >
            <ChevronRight className="w-5 h-5" />
          </Button>
        </div>

        {/* Week View Days */}
        {view === 'weekly' && (
          <div className="grid grid-cols-7 gap-1 mt-4">
            {getWeekDates(currentDate).map((date, index) => {
              const isToday = date.toDateString() === new Date().toDateString();
              const dayItems = mockScheduleItems.filter(item => 
                new Date(item.date).toDateString() === date.toDateString()
              );
              
              return (
                <div key={index} className="text-center">
                  <div className="text-xs text-muted-foreground mb-1">
                    {date.toLocaleDateString('en-AU', { weekday: 'short' })}
                  </div>
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm mx-auto relative ${
                    isToday ? 'bg-teal-dark text-white' : 'hover:bg-muted'
                  }`}>
                    {date.getDate()}
                    {/* Indicators */}
                    <div className="absolute -bottom-3 left-1/2 transform -translate-x-1/2 flex space-x-1">
                      {dayItems.length > 0 && (
                        <div className="w-1 h-1 bg-teal-dark rounded-full"></div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Content Sections */}
      <div className="px-6 py-6 space-y-6">
        {/* Today's Schedule */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg">Today&apos;s Schedule</h3>
            <Badge variant="outline" className="text-teal-dark border-teal-dark">
              {todaysItems.length} items
            </Badge>
          </div>

          {todaysItems.length > 0 ? (
            <div className="space-y-3">
              {todaysItems.map((item) => (
                <Card key={item.id} className="border-0 shadow-sm">
                  <CardContent className="p-4">
                    <div className="flex items-start space-x-3">
                      <div className={`w-3 h-3 rounded-full mt-2 ${getStatusColor(item.status)}`}></div>
                      
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <h4 className="text-sm">{item.title}</h4>
                          <Badge 
                            variant="outline" 
                            className={`text-xs ${
                              item.type === 'shift' ? 'border-blue-500 text-blue-500' : 'border-purple-500 text-purple-500'
                            }`}
                          >
                            {item.type}
                          </Badge>
                        </div>
                        
                        <div className="space-y-1 text-xs text-muted-foreground">
                          <div className="flex items-center">
                            <User className="w-3 h-3 mr-1" />
                            {item.client}
                          </div>
                          <div className="flex items-center">
                            <Clock className="w-3 h-3 mr-1" />
                            {item.time} ({item.duration})
                          </div>
                          <div className="flex items-center">
                            <MapPin className="w-3 h-3 mr-1" />
                            {item.location}
                          </div>
                        </div>

                        {/* Template Actions */}
                        <div className="flex gap-2 mt-3">
                          <Button size="sm" variant="outline" className="text-xs h-7">
                            <FileText className="w-3 h-3 mr-1" />
                            Progress Note
                          </Button>
                          <Button size="sm" variant="outline" className="text-xs h-7">
                            <Plus className="w-3 h-3 mr-1" />
                            Create Template
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <Calendar className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
              <h4 className="text-sm text-muted-foreground">No schedule today</h4>
            </div>
          )}
        </div>

        {/* Client Templates */}
        <Card className="bg-blue-50 border-blue-200">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center">
              <FileText className="w-4 h-4 mr-2 text-blue-600" />
              Client Templates
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <p className="text-xs text-blue-800 mb-3">
              Create reusable templates for regular clients to streamline your workflow.
            </p>
            <Button 
              size="sm" 
              onClick={handleCreateTemplate}
              className="bg-blue-600 hover:bg-blue-700 text-white text-xs"
            >
              <Plus className="w-3 h-3 mr-1" />
              Create New Template
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};