import React, { useState } from 'react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { useAppContext, UserRole } from '../AppContext';
import { ArrowLeft, Mail, Lock, User } from 'lucide-react';

export const SignupScreen: React.FC = () => {
  const { setCurrentScreen, signup } = useAppContext();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<UserRole | ''>('');

  const handleSignup = () => {
    if (name && email && password && role) {
      signup({
        name,
        email,
        role: role as UserRole,
        suburb: 'Richmond', // Default suburb for demo
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-sage-light to-teal-light flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between px-6 py-4 pt-12">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setCurrentScreen('welcome')}
          className="text-white hover:bg-white/20 rounded-full p-2"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <h2 className="text-white">Join Community</h2>
        <div className="w-9" />
      </div>

      {/* Signup Form */}
      <div className="flex-1 flex items-center justify-center px-6 py-6">
        <Card className="w-full max-w-sm bg-white/95 backdrop-blur-sm border-0 shadow-xl">
          <CardHeader className="text-center pb-6">
            <CardTitle className="text-2xl text-teal-dark">Sign Up</CardTitle>
            <p className="text-muted-foreground text-sm">Create your account to get started</p>
          </CardHeader>
          
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="inputName" className="text-sm">Full Name</Label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  id="inputName"
                  type="text"
                  placeholder="Enter your full name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="pl-10 py-5 rounded-xl bg-input-background border-0"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="inputEmailSignup" className="text-sm">Email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  id="inputEmailSignup"
                  type="email"
                  placeholder="Enter your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="pl-10 py-5 rounded-xl bg-input-background border-0"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="inputPasswordSignup" className="text-sm">Password</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  id="inputPasswordSignup"
                  type="password"
                  placeholder="Create a password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pl-10 py-5 rounded-xl bg-input-background border-0"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-sm">I am a...</Label>
              <Select value={role} onValueChange={(value: UserRole) => setRole(value)}>
                <SelectTrigger className="py-5 rounded-xl bg-input-background border-0">
                  <SelectValue placeholder="Select your role" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="participant">Participant (Looking for support)</SelectItem>
                  <SelectItem value="support-worker">Support Worker (Providing support)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Button
              onClick={handleSignup}
              className="w-full bg-teal-dark hover:bg-teal text-white py-5 rounded-xl shadow-lg mt-6"
              size="lg"
              disabled={!name || !email || !password || !role}
            >
              Create Account
            </Button>

            <div className="text-center">
              <Button
                variant="link"
                onClick={() => setCurrentScreen('login')}
                className="text-teal-dark hover:text-teal text-sm"
              >
                Already have an account? Log in
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};