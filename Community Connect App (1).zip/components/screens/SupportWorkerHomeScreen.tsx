import React, { useState } from 'react';
import { Button } from '../ui/button';
import { Card, CardContent } from '../ui/card';
import { Badge } from '../ui/badge';
import { useAppContext } from '../AppContext';
import { mockJobPosts, JobPost } from '../MockData';
import { MapPin, Clock, User, Check, Bookmark, Calendar, Menu, Bell } from 'lucide-react';

export const SupportWorkerHomeScreen: React.FC = () => {
  const { user, setCurrentScreen } = useAppContext();
  const [interestedJobs, setInterestedJobs] = useState<string[]>([]);
  const [savedJobs, setSavedJobs] = useState<string[]>([]);

  const handleExpressInterest = (jobId: string) => {
    setInterestedJobs(prev => [...prev, jobId]);
  };

  const handleSaveJob = (jobId: string) => {
    setSavedJobs(prev => 
      prev.includes(jobId) 
        ? prev.filter(id => id !== jobId)
        : [...prev, jobId]
    );
  };

  const handleViewJobDetails = (job: JobPost) => {
    setCurrentScreen('job-details');
    // In a real app, you'd pass the job data to the details view
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="bg-gradient-to-r from-sage to-teal px-6 py-8 pt-12">
        <div className="flex items-center justify-between mb-4">
          <div className="flex-1">
            <h1 className="text-white text-2xl">Available Jobs</h1>
            <p className="text-white/90 text-sm">Find opportunities near you</p>
          </div>
          
          {/* Top Right Actions */}
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setCurrentScreen('notifications')}
              className="text-white hover:bg-white/20 rounded-full p-2 relative"
            >
              <Bell className="w-5 h-5" />
              {/* Notification Badge */}
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full"></div>
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setCurrentScreen('menu')}
              className="text-white hover:bg-white/20 rounded-full p-2"
            >
              <Menu className="w-5 h-5" />
            </Button>
          </div>
        </div>
        
        <div className="text-white text-sm">
          {mockJobPosts.length} jobs available
        </div>
      </div>

      {/* Job Posts */}
      <div className="px-6 py-6 space-y-4">
        {mockJobPosts.map((job) => {
          const hasExpressedInterest = interestedJobs.includes(job.id);
          const isSaved = savedJobs.includes(job.id);
          
          return (
            <Card key={job.id} className="border-0 shadow-md">
              <CardContent className="p-6">
                {/* Header */}
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h3 className="text-lg mb-1">{job.title}</h3>
                    <div className="flex items-center text-muted-foreground text-sm mb-2">
                      <User className="w-4 h-4 mr-1" />
                      {job.participantName} • {job.participantSuburb}
                    </div>
                  </div>
                  
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleSaveJob(job.id)}
                    className={`p-2 ${isSaved ? 'text-teal-dark' : 'text-muted-foreground'}`}
                  >
                    <Bookmark className={`w-5 h-5 ${isSaved ? 'fill-current' : ''}`} />
                  </Button>
                </div>

                {/* Job Details */}
                <div className="space-y-2 mb-4">
                  <div className="flex items-center text-sm">
                    <Calendar className="w-4 h-4 mr-2 text-muted-foreground" />
                    {job.date} at {job.time}
                  </div>
                  
                  <div className="flex items-center text-sm">
                    <MapPin className="w-4 h-4 mr-2 text-muted-foreground" />
                    {job.location}
                  </div>
                </div>

                {/* Support Type Badge */}
                <div className="mb-4">
                  <Badge variant="outline" className="text-teal-dark border-teal-dark">
                    {job.supportType}
                  </Badge>
                </div>

                {/* Description */}
                <p className="text-muted-foreground text-sm mb-6 line-clamp-3">
                  {job.description}
                </p>

                {/* Actions */}
                <div className="flex gap-3">
                  <Button
                    onClick={() => handleViewJobDetails(job)}
                    variant="outline"
                    className="flex-1"
                  >
                    View Details
                  </Button>
                  
                  <Button
                    onClick={() => handleExpressInterest(job.id)}
                    disabled={hasExpressedInterest}
                    className={`flex-1 ${
                      hasExpressedInterest 
                        ? 'bg-green-500 hover:bg-green-600' 
                        : 'bg-teal-dark hover:bg-teal'
                    } text-white`}
                  >
                    {hasExpressedInterest ? (
                      <>
                        <Check className="w-4 h-4 mr-2" />
                        Interest Sent
                      </>
                    ) : (
                      'Express Interest'
                    )}
                  </Button>
                </div>

                {/* Interest Count */}
                {job.interestedWorkers.length > 0 && (
                  <div className="mt-3 pt-3 border-t border-border">
                    <p className="text-xs text-muted-foreground">
                      {job.interestedWorkers.length} worker{job.interestedWorkers.length !== 1 ? 's' : ''} interested
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Empty State */}
      {mockJobPosts.length === 0 && (
        <div className="flex-1 flex items-center justify-center px-6">
          <div className="text-center">
            <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
              <Calendar className="w-10 h-10 text-muted-foreground" />
            </div>
            <h3 className="text-lg mb-2">No jobs available</h3>
            <p className="text-muted-foreground text-sm">
              Check back later for new opportunities in your area.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};