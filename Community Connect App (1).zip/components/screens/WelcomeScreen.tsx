import React from 'react';
import { Button } from '../ui/button';
import { Card } from '../ui/card';
import { useAppContext } from '../AppContext';
import { Users, Shield } from 'lucide-react';
import logoImage from 'figma:asset/7a73c8d9ce31fddbc3a6405c6568ae75f73b9430.png';

export const WelcomeScreen: React.FC = () => {
  const { setCurrentScreen } = useAppContext();

  return (
    <div className="min-h-screen bg-gradient-to-br from-sage-light to-teal-light flex flex-col">
      {/* Header */}
      <div className="flex-1 flex flex-col justify-center items-center px-6 py-8">
        {/* Logo */}
        <div className="mb-8 text-center">
          <div className="w-32 h-32 mx-auto mb-6">
            <img 
              src={logoImage} 
              alt="Community Connect Logo" 
              className="w-full h-full object-contain rounded-[135px] m-[0px] p-[0px]"
            />
          </div>
          <h1 className="text-3xl text-white mb-2">Community Connect</h1>
          <p className="text-white/90">Ready To Get Connected!</p>
        </div>

        {/* Features */}
        <div className="w-full max-w-sm space-y-4 mb-12">
          <Card className="p-4 bg-white/95 backdrop-blur-sm border-0 shadow-lg">
            <div className="flex items-center space-x-3">
              <Users className="w-6 h-6 text-teal-dark" />
              <div>
                <h3 className="text-sm">Find Support Workers</h3>
                <p className="text-xs text-muted-foreground">Browse verified local professionals</p>
              </div>
            </div>
          </Card>
          
          <Card className="p-4 bg-white/95 backdrop-blur-sm border-0 shadow-lg">
            <div className="flex items-center space-x-3">
              <Shield className="w-6 h-6 text-sage-dark" />
              <div>
                <h3 className="text-sm">Safe &amp; Verified</h3>
                <p className="text-xs text-muted-foreground">All workers undergo thorough screening</p>
              </div>
            </div>
          </Card>
        </div>

        {/* Action Buttons */}
        <div className="w-full max-w-sm space-y-3">
          <Button
            onClick={() => setCurrentScreen('signup')}
            className="w-full bg-purple-700 hover:bg-purple-800 text-white py-6 rounded-2xl shadow-lg"
            size="lg"
          >
            Register
          </Button>
          
          <p className="text-center text-white/90 text-sm">
            Already Registered? Log in here.
          </p>
          
          <Button
            onClick={() => setCurrentScreen('login')}
            variant="outline"
            className="w-full bg-purple-700 hover:bg-purple-800 text-white border-purple-700 py-6 rounded-2xl shadow-lg"
            size="lg"
          >
            Log In
          </Button>
        </div>
      </div>

      {/* Footer */}
      <div className="px-6 py-4 text-center">
        <p className="text-white/70 text-xs">
          By continuing, you agree to our Terms &amp; Privacy Policy
        </p>
      </div>
    </div>
  );
};