import React from 'react';
import { Button } from '../ui/button';
import { useAppContext } from '../AppContext';
import { Home, MessageSquare, Plus, User, Search, Calendar } from 'lucide-react';

export const BottomNavigation: React.FC = () => {
  const { user, currentScreen, setCurrentScreen } = useAppContext();

  if (!user) return null;

  const isParticipant = user.role === 'participant';

  const navItems = isParticipant
    ? [
        { id: 'participant-home', icon: Home, label: 'Swipe & Match', screen: 'participant-home' },
        { id: 'job-requests', icon: Plus, label: 'Job Requests', screen: 'job-requests' },
        { id: 'inbox', icon: MessageSquare, label: 'Messages', screen: 'inbox' },
        { id: 'participant-profile', icon: User, label: 'Profile', screen: 'participant-profile' },
      ]
    : [
        { id: 'support-worker-home', icon: Search, label: 'Jobs', screen: 'support-worker-home' },
        { id: 'schedule', icon: Calendar, label: 'Schedule', screen: 'schedule' },
        { id: 'inbox', icon: MessageSquare, label: 'Messages', screen: 'inbox' },
        { id: 'worker-profile', icon: User, label: 'Profile', screen: 'worker-profile' },
      ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-border px-1 py-2 shadow-lg">
      <div className="flex justify-around max-w-md mx-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentScreen === item.screen;
          
          return (
            <Button
              key={item.id}
              variant="ghost"
              size="sm"
              onClick={() => setCurrentScreen(item.screen)}
              className={`flex flex-col items-center justify-center p-1 min-w-0 h-12 ${
                isActive 
                  ? 'text-teal-dark bg-teal-light/20' 
                  : 'text-muted-foreground hover:text-teal-dark'
              }`}
            >
              <Icon className="w-4 h-4 mb-1" />
              <span className="text-xs leading-none">{item.label}</span>
            </Button>
          );
        })}
      </div>
    </div>
  );
};